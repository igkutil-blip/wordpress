/**
 * Plan A – pristupnice u Google tablici.
 *
 * Skriptu je napravio dodatak "Plan A članstvo" (WordPress). Stranica šalje svaku novu
 * pristupnicu i potvrdu u ovu tablicu. Stupce "Članarina GGGG" i "Iskaznica uručena"
 * stranica ne mijenja: kvačice označavate ručno. "Napomena" se popunjava samo pri uvozu
 * i samo ako je prazna, pa je možete slobodno mijenjati. Stupac "Br." nemojte brisati ni mijenjati
 * (po njemu se pronalazi red), a tablicu smijete sortirati i filtrirati.
 */
var SECRET = '{{SECRET}}';
var SCRIPT_VERSION = 9;
var SITE = '{{SITE}}';
var AG_ID = '{{AG}}';
var SHEET_NAME = 'Članovi';
var HEAD = ['Br.', 'Datum prijave', 'Ime', 'Prezime', 'Datum rođenja', 'OIB', 'Adresa', 'Mjesto, poštanski broj', 'E-mail', 'Mobitel', 'Roditelj ili skrbnik', 'Status', 'Datum potvrde'];
var KEYS = ['broj', 'prijava', 'ime', 'prezime', 'datum', 'oib', 'adresa', 'mjesto', 'email', 'mobitel', 'roditelj', 'status', 'potvrda'];
var YEAR_PREFIX = 'Članarina ';
var CARD = 'Iskaznica uručena';
var NOTE = 'Napomena';

function doPost(e) {
  var out;
  try {
    var d = JSON.parse(e.postData.contents);
    if (d.secret !== SECRET) {
      return json_({ ok: false, error: 'Pogrešan ključ.' });
    }
    if (d.ag) agRemember_(d.ag);
    var lock = LockService.getScriptLock();
    lock.waitLock(25000);
    try {
      var sh = sheet_();
      if (d.action === 'ping') {
        out = { ok: true, name: SpreadsheetApp.getActive().getName() };
      } else if (d.action === 'upsert') {
        upsertMany_(sh, [d]);
        out = { ok: true };
      } else if (d.action === 'bulk') {
        out = { ok: true, n: upsertMany_(sh, d.rows || []) };
      } else if (d.action === 'ag_tours') {
        out = { ok: true, n: agTours_(agSheet_(d.ag), d.tours || []) };
      } else if (d.action === 'ag_add') {
        out = { ok: true, n: agAdd_(agSheet_(d.ag), d.rows || []) };
      } else if (d.action === 'ag_status') {
        out = { ok: true, n: agStatus_(agSheet_(d.ag), d.items || []) };
      } else if (d.action === 'ag_paid') {
        var ash = agSheet_(d.ag);
        out = { ok: true, orders: agPaid_(ash, null), local: agLocalRefresh_(ash) };
      } else if (d.action === 'read') {
        out = { ok: true, rows: read_(sh) };
      } else if (d.action === 'renumber') {
        out = { ok: true, n: renumber_(sh, d.map || {}) };
      } else if (d.action === 'delete') {
        var r = findRow_(sh, d.broj);
        if (r) sh.deleteRow(r);
        out = { ok: true };
      } else {
        out = { ok: false, error: 'Nepoznata radnja.' };
      }
      SpreadsheetApp.flush();
    } finally {
      lock.releaseLock();
    }
  } catch (err) {
    out = { ok: false, error: String(err) };
  }
  out.v = SCRIPT_VERSION;
  return json_(out);
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function sheet_() {
  var ss = SpreadsheetApp.getActive();
  var sh = ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME, 0);
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, HEAD.length).setValues([HEAD]);
    sh.setFrozenRows(1);
    sh.getRange('F:F').setNumberFormat('@'); // OIB kao tekst (vodeće nule)
    sh.getRange('J:J').setNumberFormat('@'); // mobitel kao tekst
  }
  cardCol_(sh);
  noteCol_(sh);
  yearCol_(sh, new Date().getFullYear());
  styleHead_(sh);
  return sh;
}

function styleHead_(sh) {
  var head = sh.getRange(1, 1, 1, sh.getLastColumn());
  head.setFontWeight('bold').setBackground('#12304b').setFontColor('#ffffff').setWrap(true).setVerticalAlignment('middle');
}

/** Stupac "Članarina GGGG" (s kvačicama); vraća broj stupca. */
function yearCol_(sh, year) {
  var last = sh.getLastColumn();
  var heads = sh.getRange(1, 1, 1, last).getValues()[0];
  var name = YEAR_PREFIX + year;
  var at = heads.indexOf(name);
  if (at >= 0) return at + 1;
  // Godine idu redom: novi stupac prije prve veće godine, a uvijek ispred stupca
  // "Iskaznica uručena" i vlastitih stupaca na kraju.
  var col = last + 1;
  for (var i = HEAD.length; i < heads.length; i++) {
    var h = String(heads[i]);
    if (h.indexOf(YEAR_PREFIX) !== 0) { col = i + 1; break; }
    var y = parseInt(h.replace(YEAR_PREFIX, ''), 10);
    if (y > year) { col = i + 1; break; }
  }
  if (col <= last) sh.insertColumnBefore(col); else sh.insertColumnAfter(last);
  sh.getRange(1, col).setValue(name);
  var rows = sh.getLastRow() - 1;
  if (rows > 0) sh.getRange(2, col, rows, 1).insertCheckboxes();
  sh.setColumnWidth(col, 110);
  return col;
}

/** Stupac "Iskaznica uručena" (s kvačicama), na kraju; vraća broj stupca. */
function cardCol_(sh) {
  var last = sh.getLastColumn();
  var heads = sh.getRange(1, 1, 1, last).getValues()[0];
  var at = heads.indexOf(CARD);
  if (at >= 0) return at + 1;
  var col = last + 1;
  sh.insertColumnAfter(last);
  sh.getRange(1, col).setValue(CARD);
  var rows = sh.getLastRow() - 1;
  if (rows > 0) sh.getRange(2, col, rows, 1).insertCheckboxes();
  sh.setColumnWidth(col, 120);
  return col;
}

/** Stupac "Napomena" (običan tekst), iza stupca za iskaznicu; vraća broj stupca. */
function noteCol_(sh) {
  var last = sh.getLastColumn();
  var heads = sh.getRange(1, 1, 1, last).getValues()[0];
  var at = heads.indexOf(NOTE);
  if (at >= 0) return at + 1;
  var col = heads.indexOf(CARD) + 2;
  if (col <= last) sh.insertColumnBefore(col); else sh.insertColumnAfter(last);
  sh.getRange(1, col).setValue(NOTE);
  sh.setColumnWidth(col, 220);
  return col;
}

/** Stupci s kvačicama: "Članarina GGGG" i "Iskaznica uručena". */
function isBox_(h) {
  h = String(h);
  return h === CARD || h.indexOf(YEAR_PREFIX) === 0;
}

/** Kvačice iz tablice (stranica ih čita): za svaki broj označene godine i iskaznica. */
function read_(sh) {
  var last = sh.getLastRow(), lastCol = sh.getLastColumn();
  if (last < 2) return [];
  var heads = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(String);
  var data = sh.getRange(2, 1, last - 1, lastCol).getValues();
  var years = [];
  heads.forEach(function (h, c) {
    if (h.indexOf(YEAR_PREFIX) === 0) years.push([c, parseInt(h.replace(YEAR_PREFIX, ''), 10)]);
  });
  var cardC = heads.indexOf(CARD);
  var out = [];
  data.forEach(function (r) {
    var b = parseInt(r[0], 10);
    if (!b) return;
    var y = [];
    years.forEach(function (p) { if (r[p[0]] === true) y.push(p[1]); });
    out.push({ b: b, y: y, k: cardC >= 0 && r[cardC] === true ? 1 : 0 });
  });
  return out;
}

/** Novi brojevi članova (stari → novi), pa redovi poredani po broju; kvačice idu s redom. */
function renumber_(sh, map) {
  var last = sh.getLastRow();
  if (last < 2) return 0;
  var col = sh.getRange(2, 1, last - 1, 1).getValues();
  var n = 0;
  col.forEach(function (r) {
    var k = String(r[0]);
    if (Object.prototype.hasOwnProperty.call(map, k)) { r[0] = map[k]; n++; }
  });
  sh.getRange(2, 1, last - 1, 1).setValues(col);
  sh.getRange(2, 1, last - 1, sh.getLastColumn()).sort({ column: 1, ascending: true });
  return n;
}

function findRow_(sh, broj) {
  if (!broj || sh.getLastRow() < 2) return 0;
  var f = sh.getRange(2, 1, sh.getLastRow() - 1, 1).createTextFinder(String(broj)).matchEntireCell(true).findNext();
  return f ? f.getRow() : 0;
}

function clean_(v) {
  v = v === undefined || v === null ? '' : String(v);
  // Tekst koji počinje s = + - @ ne smije postati formula.
  return /^[=+\-@]/.test(v) ? "'" + v : v;
}

/**
 * Upis cijelog paketa odjednom: tablica se pročita jednom, novi redovi upišu se jednim
 * potezom na kraj, a postojeći dobiju samo svoje podatke (i kvačice koje nedostaju).
 */
function upsertMany_(sh, items) {
  items = (items || []).filter(function (it) { return it && it.row && it.row.broj; });
  if (!items.length) return 0;
  var years = {};
  items.forEach(function (it) { (it.godine || []).forEach(function (y) { years[parseInt(y, 10)] = 1; }); });
  Object.keys(years).sort().forEach(function (y) { yearCol_(sh, parseInt(y, 10)); });

  var lastCol = sh.getLastColumn();
  var heads = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(String);
  var cardC = heads.indexOf(CARD), noteC = heads.indexOf(NOTE), statusC = KEYS.indexOf('status');
  var lastRow = sh.getLastRow();
  var ids = lastRow > 1 ? sh.getRange(2, 1, lastRow - 1, 1).getValues() : [];
  var index = {};
  ids.forEach(function (r, i) { if (r[0] !== '') index[String(r[0])] = i + 2; });

  var fresh = [], freshAt = {};
  items.forEach(function (it) {
    var key = String(it.row.broj);
    var keys = KEYS.map(function (k) { return clean_(it.row[k]); });
    var boxes = [];
    (it.godine || []).forEach(function (y) { var c = heads.indexOf(YEAR_PREFIX + parseInt(y, 10)); if (c >= 0) boxes.push(c); });
    if (it.iskaznica && cardC >= 0) boxes.push(cardC);
    var note = it.napomena && noteC >= 0 ? clean_(it.napomena) : '';
    var r = index[key];
    if (r) {
      // Postojeći red: osnovni podaci, kvačice samo dodati, napomena samo ako je prazna.
      sh.getRange(r, 1, 1, KEYS.length).setValues([keys]);
      sh.getRange(r, statusC + 1).setBackground(it.row.status === 'Potvrđeno' ? '#d9f2e3' : '#fdebd3');
      if (boxes.length || note) {
        var line = sh.getRange(r, 1, 1, lastCol).getValues()[0];
        boxes.forEach(function (c) { if (line[c] !== true) sh.getRange(r, c + 1).insertCheckboxes().setValue(true); });
        if (note && line[noteC] === '') sh.getRange(r, noteC + 1).setValue(note);
      }
      return;
    }
    var row = freshAt[key];
    if (row === undefined) {
      row = heads.map(function (h, c) { return c >= HEAD.length && isBox_(h) ? false : ''; });
      freshAt[key] = row;
      fresh.push(row);
    }
    keys.forEach(function (v, c) { row[c] = v; });
    boxes.forEach(function (c) { row[c] = true; });
    if (note && row[noteC] === '') row[noteC] = note;
  });

  if (fresh.length) {
    var start = lastRow + 1;
    heads.forEach(function (h, c) {
      if (c >= HEAD.length && isBox_(h)) sh.getRange(start, c + 1, fresh.length, 1).insertCheckboxes();
    });
    sh.getRange(start, 1, fresh.length, lastCol).setValues(fresh);
    sh.getRange(start, statusC + 1, fresh.length, 1).setBackgrounds(fresh.map(function (row) {
      return [row[statusC] === 'Potvrđeno' ? '#d9f2e3' : '#fdebd3'];
    }));
  }
  return items.length;
}

/* ==========================================================================
 * Tablica za agenciju: "Prijave na izlete" (posebna Google tablica, list "Prijave").
 * Svaki izlet je blok (naslov, nazivi stupaca, osobe, prazan red); novi izlet ide na vrh.
 * Skriveni zadnji stupac "ključ" povezuje redove sa stranicom. Stranica upisuje svaku
 * osobu samo jednom; obrisani red se ne vraća.
 * - Uplaćeno: kad su označene sve osobe iz narudžbe (osim otkazanih), narudžba postaje
 *   "Završeno" i kupac dobiva e-mail.
 * - Otkazao: red posivi; kad otkažu svi iz narudžbe, narudžba se otkazuje (e-mail ide
 *   samo vama).
 * - Ime i prezime: zamjena u istom redu ili nova osoba u novom redu. Ostali podaci
 *   upisuju se iz tablice članova, a brojevi (Br.) se slože ispočetka.
 * Napomena i sve što dopišete ostaje.
 * ======================================================================== */
var AG_SHEET = 'Prijave';
var AG_HEAD = ['Br.', 'Ime', 'Prezime', 'OIB', 'Datum rođenja', 'Adresa', 'Mjesto', 'Mobitel', 'E-mail', 'Prijavio/la', 'Iznos', 'Osiguranje', 'Uplaćeno', 'Otkazao', 'Pristupnica', 'Članarina', 'Iskaznica', 'Napomena', 'Narudžba', 'ključ'];
var AG_KEYS = ['', 'ime', 'prezime', 'oib', 'datum', 'adresa', 'mjesto', 'mobitel', 'email', 'prijavio', 'iznos', 'osiguranje', 'uplaceno', 'otkazao', 'pristupnica', 'clanarina', 'iskaznica', 'napomena', 'narudzba'];
var AG_BOX = { osiguranje: 1, uplaceno: 1, otkazao: 1, clanarina: 1, iskaznica: 1 };
var AG_PERSON = ['oib', 'datum', 'adresa', 'mjesto', 'mobitel', 'email']; // iz tablice članova
var AG_KEY_COL = AG_HEAD.length; // skriveni stupac
var AG_LAST = AG_HEAD.length - 1; // zadnji vidljivi stupac
var AG_GREY = '#e6e6e6';
var AG_AUTO = /^(nije član – |više članova s tim imenom|zamjena za )/; // napomene koje piše skripta

/** Broj stupca za ključ iz AG_KEYS. */
function agC_(k) {
  return AG_KEYS.indexOf(k) + 1;
}

/**
 * Brzo osvježavanje: pokreni JEDNOM u uređivaču (Run) i dopusti pristup. Nakon toga:
 * - kvačice "Članarina GGGG" i "Iskaznica uručena" u tablici članova odmah idu na stranicu
 *   i u tablicu za agenciju;
 * - u tablici za agenciju kvačice "Uplaćeno" i "Otkazao" odmah mijenjaju narudžbu, a
 *   upisano ime i prezime povlači ostale podatke iz tablice članova.
 * Ponovno pokretanje ne pravi duple okidače.
 */
function ukljuciBrzoOsvjezavanje() {
  var ss = SpreadsheetApp.getActive();
  PropertiesService.getScriptProperties().setProperty('MEM', ss.getId());
  ScriptApp.getProjectTriggers().forEach(function (t) {
    var f = t.getHandlerFunction();
    if (f === 'naIzmjenu' || f === 'naPromjenu') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('naIzmjenu').forSpreadsheet(ss).onEdit().create();
  var ag = agId_();
  if (!ag) return 'Brzo osvježavanje je uključeno za tablicu članova. Tablica za agenciju još nije poznata: na stranici klikni "Provjeri vezu" i ponovno pokreni ovu funkciju.';
  ScriptApp.newTrigger('naIzmjenu').forSpreadsheet(ag).onEdit().create();
  ScriptApp.newTrigger('naPromjenu').forSpreadsheet(ag).onChange().create();
  agSheet_(ag); // dodaje stupac "Otkazao" ako ga još nema
  return 'Brzo osvježavanje je uključeno (tablica članova i tablica za agenciju).';
}

function agRemember_(id) {
  id = String(id);
  var p = PropertiesService.getScriptProperties();
  if (p.getProperty('AG') !== id) p.setProperty('AG', id);
  var mem = SpreadsheetApp.getActive();
  if (mem && p.getProperty('MEM') !== mem.getId()) p.setProperty('MEM', mem.getId());
}

function agId_() {
  return PropertiesService.getScriptProperties().getProperty('AG') || (AG_ID.indexOf('{{') === 0 ? '' : AG_ID);
}

function post_(payload) {
  payload.secret = SECRET;
  UrlFetchApp.fetch(SITE, {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  });
}

/** Okidač za obje tablice (promjena ćelije). */
function naIzmjenu(e) {
  try {
    if (!e || !e.range || !SITE || SITE.indexOf('{{') === 0) return;
    var sh = e.range.getSheet();
    if (sh.getName() === AG_SHEET) return agNaIzmjenu_(e, sh);
    if (sh.getName() !== SHEET_NAME) return;
    var r0 = Math.max(2, e.range.getRow()), r1 = e.range.getLastRow();
    if (r1 < r0) return;
    var lastCol = sh.getLastColumn();
    var heads = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(String);
    var touched = false;
    for (var c = e.range.getColumn(); c <= e.range.getLastColumn(); c++) {
      if (isBox_(heads[c - 1])) touched = true;
    }
    if (!touched) return;
    var years = [];
    heads.forEach(function (h, c) { if (h.indexOf(YEAR_PREFIX) === 0) years.push([c, parseInt(h.replace(YEAR_PREFIX, ''), 10)]); });
    var cardC = heads.indexOf(CARD);
    var data = sh.getRange(r0, 1, r1 - r0 + 1, lastCol).getValues();
    var rows = [];
    data.forEach(function (r) {
      var b = parseInt(r[0], 10);
      if (!b) return;
      var y = [];
      years.forEach(function (p) { if (r[p[0]] === true) y.push(p[1]); });
      rows.push({ b: b, y: y, k: cardC >= 0 && r[cardC] === true ? 1 : 0 });
    });
    if (!rows.length) return;
    post_({ rows: rows });
    // Ručno upisane osobe i zamjene u tablici za agenciju vodi skripta.
    var ag = agId_();
    if (ag) {
      var lock = LockService.getScriptLock();
      lock.waitLock(25000);
      try {
        agLocalRefresh_(agSheet_(ag));
      } finally {
        lock.releaseLock();
      }
    }
  } catch (err) {
    console.error(err);
  }
}

/** Okidač za tablicu za agenciju (dodan ili obrisan red): brojevi i zbrojevi ispočetka. */
function naPromjenu(e) {
  try {
    if (!e || (e.changeType !== 'INSERT_ROW' && e.changeType !== 'REMOVE_ROW')) return;
    var sh = e.source.getSheetByName(AG_SHEET);
    if (!sh) return;
    var lock = LockService.getScriptLock();
    lock.waitLock(25000);
    try {
      agMigrate_(sh);
      var ix = agIndex_(sh);
      ix.blocks.forEach(function (b) { agNumber_(sh, ix, b); agCount_(sh, ix, b); });
    } finally {
      lock.releaseLock();
    }
  } catch (err) {
    console.error(err);
  }
}

/** Ovo pokreni jednom u uređivaču (Run), da Google dopusti pristup tablici za agenciju. */
function ovlasti() {
  return SpreadsheetApp.getActive().getName();
}

function str_(v) {
  if (v instanceof Date) return Utilities.formatDate(v, Session.getScriptTimeZone(), 'd.M.yyyy.');
  return v === null || v === undefined ? '' : String(v).trim();
}

function agSheet_(id) {
  if (!id) throw new Error('Tablica za agenciju nije upisana u postavkama.');
  var ss = SpreadsheetApp.openById(id);
  var sh = ss.getSheetByName(AG_SHEET);
  if (!sh) {
    sh = ss.insertSheet(AG_SHEET, 0);
    sh.getRange(1, 1).setValue('Prijave na izlete – Plan A · novi izlet je na vrhu · Uplaćeno: kad su označene sve osobe iz narudžbe, kupac dobiva potvrdu · Otkazao: osoba ne ide (kad otkažu svi, narudžba se otkazuje) · zamjena: upišite novo ime i prezime u isti red, ostalo se upiše iz tablice članova · Napomena je vaša');
    sh.getRange(1, 1, 1, AG_LAST).merge().setFontStyle('italic').setFontColor('#5f6b77').setWrap(true);
    sh.setFrozenRows(1);
    sh.getRange(1, AG_KEY_COL).setValue('ključ');
    sh.hideColumns(AG_KEY_COL);
    var w = [45, 110, 130, 105, 95, 170, 130, 115, 190, 140, 80, 85, 80, 80, 115, 90, 85, 260, 80];
    w.forEach(function (px, i) { sh.setColumnWidth(i + 1, px); });
    sh.getRange('D:D').setNumberFormat('@');
    sh.getRange('H:H').setNumberFormat('@');
  }
  agMigrate_(sh);
  return sh;
}

/**
 * Starija tablica (bez stupca "Otkazao"): umetni ga iza "Uplaćeno". Sivi (otkazani) redovi
 * dobivaju kvačicu. Radi se samo jednom.
 */
function agMigrate_(sh) {
  if (String(sh.getRange(1, AG_KEY_COL - 1).getValue()) !== 'ključ') return;
  var oc = agC_('otkazao');
  sh.insertColumnBefore(oc);
  sh.getRange(1, oc, sh.getMaxRows(), 1).clearDataValidations().clearContent();
  sh.setColumnWidth(oc, 80);
  var ix = agIndex_(sh);
  var bg = ix.last ? sh.getRange(1, 1, ix.last, 1).getBackgrounds() : [];
  for (var r = 2; r <= ix.last; r++) {
    var info = ix.info[r] || {};
    if (info.kind === 'H') {
      sh.getRange(r, oc).setValue('Otkazao');
    } else if (info.kind !== 'T' && agIsPerson_(ix, r)) {
      var grey = String(bg[r - 1][0]).toLowerCase() === AG_GREY;
      sh.getRange(r, oc).insertCheckboxes().setValue(grey);
    }
  }
}

function agNorm_(t) {
  return String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/[^a-z0-9]+/g, ' ').trim();
}

/**
 * Pregled lista: blokovi (naslovni redovi), osobe (po ključu) i vrsta svakog reda:
 * T naslov, H nazivi stupaca, P osoba sa stranice (pkey, izvorno ime, narudžba),
 * M osoba koju ste dodali ručno. Red s imenom bez ključa je također osoba.
 */
function agIndex_(sh) {
  var last = sh.getLastRow();
  var data = last > 0 ? sh.getRange(1, 1, last, AG_HEAD.length).getValues() : [];
  var blocks = [], persons = {}, info = {};
  data.forEach(function (r, i) {
    var k = String(r[AG_KEY_COL - 1] || ''), p = k.split('|');
    if (p[0] === 'T' && p.length > 1) {
      blocks.push({ key: p[1], date: p[2] || '', title: p[3] || '', base: p.slice(4).join('|'), row: i + 1 });
      info[i + 1] = { kind: 'T' };
    } else if (p[0] === 'H' && p.length > 1) {
      info[i + 1] = { kind: 'H' };
    } else if (p[0] === 'P' && p.length > 1) {
      persons[p[1]] = i + 1;
      var m = /^o(\d+)-/.exec(p[1]);
      info[i + 1] = { kind: 'P', pkey: p[1], orig: p.length > 2 ? p.slice(2).join('|') : undefined, o: m ? parseInt(m[1], 10) : 0 };
    } else if (p[0] === 'M') {
      info[i + 1] = { kind: 'M' };
    }
  });
  return { last: last, data: data, blocks: blocks, persons: persons, info: info };
}

function agIsPerson_(ix, r) {
  var row = ix.data[r - 1] || [], info = ix.info[r] || {};
  if (info.kind === 'T' || info.kind === 'H') return false;
  return info.kind === 'P' || info.kind === 'M' || String(row[1] || '') + String(row[2] || '') !== '';
}

function agName_(row) {
  return (str_(row[1]) + ' ' + str_(row[2])).trim();
}

/** Red koji vodi skripta (ručno dodan ili zamjena): podaci i stanje iz tablice članova. */
function agIsLocal_(ix, r) {
  var info = ix.info[r] || {};
  if (info.kind === 'M') return true;
  if (!info.kind) return agIsPerson_(ix, r);
  if (info.kind !== 'P' || info.orig === undefined) return false;
  return info.orig === '?' || agNorm_(info.orig) !== agNorm_(agName_(ix.data[r - 1]));
}

/** Redovi osoba u bloku: [prvi, zadnji]; prazan blok: zadnji = red s nazivima stupaca. */
function agBlockRows_(ix, b) {
  var next = ix.last + 1;
  ix.blocks.forEach(function (o) { if (o.row > b.row && o.row < next) next = o.row; });
  var end = b.row + 1, n = 0;
  for (var r = b.row + 2; r < next; r++) {
    if (agIsPerson_(ix, r)) { end = r; n++; }
  }
  return { first: b.row + 2, end: end, n: n };
}

function agBlockOf_(ix, r) {
  var b = null;
  ix.blocks.forEach(function (o) { if (o.row < r && (!b || o.row > b.row)) b = o; });
  return b;
}

/** Godina izleta (za stupac "Članarina GGGG"). */
function agYear_(b) {
  var y = parseInt(String(b.date || '').substring(0, 4), 10);
  return y > 2000 ? y : new Date().getFullYear();
}

function agTitleText_(base, n, paid, x) {
  return base + ' · prijavljeno ' + n + ' · uplaćeno ' + paid + (x ? ' · otkazalo ' + x : '');
}

/** Osvježi brojke u naslovu bloka (otkazani se ne broje u prijavljene). */
function agCount_(sh, ix, b) {
  var br = agBlockRows_(ix, b), n = 0, paid = 0, x = 0, pc = agC_('uplaceno') - 1, xc = agC_('otkazao') - 1;
  for (var r = br.first; r <= br.end; r++) {
    if (!agIsPerson_(ix, r)) continue;
    var row = ix.data[r - 1];
    if (row[xc] === true) { x++; continue; }
    n++;
    if (row[pc] === true) paid++;
  }
  var text = agTitleText_(b.base, n, paid, x);
  if (String(ix.data[b.row - 1][0]) !== text) {
    sh.getRange(b.row, 1).setValue(text);
    ix.data[b.row - 1][0] = text;
  }
}

/** Brojevi osoba u bloku redom 1, 2, 3 … */
function agNumber_(sh, ix, b) {
  var br = agBlockRows_(ix, b);
  if (br.end < br.first) return;
  var vals = [], n = 0, changed = false;
  for (var r = br.first; r <= br.end; r++) {
    var cur = ix.data[r - 1][0];
    if (agIsPerson_(ix, r)) {
      n++;
      if (Number(cur) !== n) changed = true;
      vals.push([n]);
    } else {
      vals.push([cur]);
    }
  }
  if (!changed) return;
  sh.getRange(br.first, 1, vals.length, 1).setValues(vals);
  vals.forEach(function (v, i) { ix.data[br.first + i - 1][0] = v[0]; });
}

function agRefresh_(sh, ix) {
  var nix = agIndex_(sh);
  ix.last = nix.last; ix.data = nix.data; ix.blocks = nix.blocks; ix.persons = nix.persons; ix.info = nix.info;
}

function agFind_(ix, key) {
  var b = null;
  ix.blocks.forEach(function (o) { if (!b && o.key === key) b = o; });
  return b;
}

/** Nađe blok izleta ili ga napravi na vrhu. t: {key, date, title, base, year} */
function agBlock_(sh, ix, t) {
  t.key = String(t.key).replace(/\|/g, '_');
  t.base = String(t.base || t.title || '');
  t.date = String(t.date || '').replace(/\|/g, '');
  var b = agFind_(ix, t.key);
  if (!b) {
    // Blok iz starog popisa: isti datum (ili mjesec) i sličan naziv.
    var nt = agNorm_(t.title), a = nt.split(' ').slice(0, 2).join(' ');
    ix.blocks.forEach(function (o) {
      if (b || o.key.indexOf('old-') !== 0 || !o.date || String(t.date).indexOf(o.date) !== 0) return;
      var c = o.title.split(' ').slice(0, 2).join(' ');
      if (a && (o.title.indexOf(a) === 0 || nt.indexOf(c) === 0)) b = o;
    });
    if (b) {
      sh.getRange(b.row, AG_KEY_COL).setValue(['T', t.key, t.date, b.title, b.base].join('|'));
      agRefresh_(sh, ix);
      return agFind_(ix, t.key);
    }
  }
  if (b) return b;
  sh.insertRowsBefore(2, 3);
  sh.getRange(2, 1, 3, AG_HEAD.length).breakApart().clearContent().clearFormat().clearDataValidations();
  sh.getRange(2, 1, 1, AG_LAST).merge().setValue(agTitleText_(t.base, 0, 0, 0)).setFontWeight('bold').setFontSize(12).setBackground('#12304b').setFontColor('#ffffff').setVerticalAlignment('middle');
  sh.setRowHeight(2, 30);
  sh.getRange(2, AG_KEY_COL).setValue(['T', t.key, t.date, agNorm_(t.title), t.base].join('|'));
  var head = AG_HEAD.slice(0, AG_LAST).map(function (h) { return h === 'Članarina' && t.year ? 'Članarina ' + t.year : h; });
  sh.getRange(3, 1, 1, AG_LAST).setValues([head]).setFontWeight('bold').setBackground('#e8eef4').setFontColor('#12304b').setWrap(true);
  sh.getRange(3, AG_KEY_COL).setValue('H|' + t.key);
  agRefresh_(sh, ix);
  return agFind_(ix, t.key);
}

function agTours_(sh, tours) {
  var ix = agIndex_(sh), n = 0;
  tours.forEach(function (t) { if (t && t.key && agBlock_(sh, ix, t)) n++; });
  return n;
}

function agPristupnica_(cell, v) {
  v = String(v || '');
  var c = v.indexOf('potvrđ') === 0 ? '#1e7d3a' : (v.indexOf('nije') === 0 ? '#b26200' : '#b32d2e');
  cell.setValue(v).setFontColor(v ? c : null).setFontWeight(v ? 'bold' : 'normal');
}

function agGrey_(sh, r, on) {
  sh.getRange(r, 1, 1, AG_LAST).setBackground(on ? AG_GREY : null).setFontColor(on ? '#777777' : null);
}

/** Nove osobe: rows [{tour: {...}, pkey, v: {ime, prezime, …}}]. Postojeći ključ se preskače. */
function agAdd_(sh, rows) {
  var ix = agIndex_(sh), n = 0, done = {};
  rows.forEach(function (it) {
    if (!it || !it.pkey || !it.tour) return;
    it.pkey = String(it.pkey).replace(/\|/g, '_');
    if (ix.persons[it.pkey]) return;
    var b = agBlock_(sh, ix, it.tour);
    if (!b) return;
    var br = agBlockRows_(ix, b);
    sh.insertRowAfter(br.end);
    var r = br.end + 1, v = it.v || {};
    v.otkazao = !!(v.otkazao || v.otkazano);
    var line = AG_KEYS.map(function (k) {
      if (k === '') return br.n + 1;
      if (AG_BOX[k]) return !!v[k];
      var x = v[k] === undefined || v[k] === null ? '' : String(v[k]);
      return /^[=+\-@]/.test(x) ? "'" + x : x;
    });
    sh.getRange(r, 1, 1, AG_HEAD.length).breakApart().clearFormat().clearDataValidations();
    Object.keys(AG_BOX).forEach(function (k) { sh.getRange(r, agC_(k)).insertCheckboxes(); });
    sh.getRange(r, 1, 1, AG_LAST).setValues([line]);
    agPristupnica_(sh.getRange(r, agC_('pristupnica')), v.pristupnica);
    var orig = (String(v.ime || '') + ' ' + String(v.prezime || '')).trim().replace(/\|/g, ' ');
    sh.getRange(r, AG_KEY_COL).setValue('P|' + it.pkey + '|' + orig);
    if (v.otkazao) agGrey_(sh, r, true);
    n++;
    agRefresh_(sh, ix);
    done[b.key] = 1;
  });
  Object.keys(done).forEach(function (k) { var b = agFind_(ix, k); if (b) agCount_(sh, ix, b); });
  return n;
}

/**
 * Osvježavanje sa stranice: items [{k, u, p, c, i, x}] (null = ne mijenjaj). Obrisani redovi
 * se preskaču, a zamjene (drugo ime nego na stranici) zadržavaju stanje iz tablice članova.
 */
function agStatus_(sh, items) {
  var ix = agIndex_(sh), n = 0, touched = {};
  items.forEach(function (it) {
    var r = ix.persons[String(it.k).replace(/\|/g, '_')];
    if (!r) return;
    var row = ix.data[r - 1], local = agIsLocal_(ix, r);
    var set = function (k, val) {
      if (val === null || val === undefined || row[agC_(k) - 1] === !!val) return;
      sh.getRange(r, agC_(k)).setValue(!!val);
      row[agC_(k) - 1] = !!val;
    };
    if (it.u === true) set('uplaceno', true);
    if (!local) {
      set('clanarina', it.c); set('iskaznica', it.i);
      if (it.p !== null && it.p !== undefined && String(row[agC_('pristupnica') - 1]) !== String(it.p)) agPristupnica_(sh.getRange(r, agC_('pristupnica')), it.p);
    }
    if (it.x && row[agC_('otkazao') - 1] !== true) {
      set('otkazao', true);
      agGrey_(sh, r, true);
    }
    n++;
    var b = agBlockOf_(ix, r);
    if (b) touched[b.key] = b;
  });
  Object.keys(touched).forEach(function (k) { agCount_(sh, ix, touched[k]); });
  return n;
}

/* ---------- Tablica članova kao baza za tablicu agencije ---------- */

function memSheet_() {
  var id = PropertiesService.getScriptProperties().getProperty('MEM');
  var ss = id ? SpreadsheetApp.openById(id) : SpreadsheetApp.getActive();
  return ss ? ss.getSheetByName(SHEET_NAME) : null;
}

/** Članovi po imenu (popis), OIB-u i e-mailu. */
function memIndex_() {
  var out = { name: {}, oib: {}, email: {} };
  var sh = memSheet_();
  if (!sh || sh.getLastRow() < 2) return out;
  var lastCol = sh.getLastColumn();
  var heads = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(String);
  var data = sh.getRange(2, 1, sh.getLastRow() - 1, lastCol).getValues();
  var c = function (k) { return KEYS.indexOf(k); };
  var cardC = heads.indexOf(CARD);
  data.forEach(function (r) {
    if (!parseInt(r[0], 10)) return;
    var m = {
      oib: str_(r[c('oib')]), datum: str_(r[c('datum')]), adresa: str_(r[c('adresa')]),
      mjesto: str_(r[c('mjesto')]), mobitel: str_(r[c('mobitel')]), email: str_(r[c('email')]),
      potvrdeno: str_(r[c('status')]) === 'Potvrđeno', iskaznica: cardC >= 0 && r[cardC] === true, godine: {}
    };
    heads.forEach(function (h, i) { if (h.indexOf(YEAR_PREFIX) === 0 && r[i] === true) m.godine[parseInt(h.replace(YEAR_PREFIX, ''), 10)] = 1; });
    var n = agNorm_(str_(r[c('ime')]) + ' ' + str_(r[c('prezime')]));
    if (n) (out.name[n] = out.name[n] || []).push(m);
    var o = m.oib.replace(/\D/g, '');
    if (o) out.oib[o] = m;
    if (m.email) out.email[m.email.toLowerCase()] = m;
  });
  return out;
}

/** Član po OIB-u, e-mailu ili imenu i prezimenu. byName = samo po imenu (zamjena). */
function memFind_(mi, row, byName) {
  if (!byName) {
    var oib = str_(row[agC_('oib') - 1]).replace(/\D/g, ''), email = str_(row[agC_('email') - 1]).toLowerCase();
    if (oib.length === 11 && mi.oib[oib]) return { m: mi.oib[oib] };
    if (email && mi.email[email]) return { m: mi.email[email] };
  }
  var l = mi.name[agNorm_(agName_(row))] || [];
  return l.length === 1 ? { m: l[0] } : { m: null, more: l.length > 1 };
}

/** Napomena: makni stare automatske dijelove (drop) i dodaj tekst. Ostalo ostaje. */
function agNote_(sh, r, row, text, drop) {
  var nc = agC_('napomena'), cur = str_(row[nc - 1]);
  var parts = cur ? cur.split(' · ') : [];
  if (drop) parts = parts.filter(function (p) { return !drop.test(p); });
  if (text && parts.indexOf(text) < 0) parts.push(text);
  var nv = parts.join(' · ');
  if (nv === cur) return;
  sh.getRange(r, nc).setValue(/^[=+\-@]/.test(nv) ? "'" + nv : nv);
  row[nc - 1] = nv;
}

/** Kvačice u ručno dodanom redu (gdje ih još nema). */
function agBoxes_(sh, r, row) {
  Object.keys(AG_BOX).forEach(function (k) {
    if (row[agC_(k) - 1] === '') {
      sh.getRange(r, agC_(k)).insertCheckboxes();
      row[agC_(k) - 1] = false;
    }
  });
}

function agBox_(sh, r, row, k, val) {
  if (row[agC_(k) - 1] === val) return;
  sh.getRange(r, agC_(k)).setValue(val);
  row[agC_(k) - 1] = val;
}

/**
 * Podaci iz tablice članova. overwrite: nova osoba u redu (zamjena), pa se prepišu i
 * popunjena polja; inače se popunjavaju samo prazna. Pristupnica, Članarina i Iskaznica
 * uvijek prema tablici članova.
 */
function agApply_(sh, r, row, f, year, overwrite) {
  var m = f.m;
  AG_PERSON.forEach(function (k) {
    var c = agC_(k), cur = str_(row[c - 1]), nv = m ? m[k] : '';
    if (overwrite ? cur === nv : (cur !== '' || nv === '')) return;
    sh.getRange(r, c).setValue(/^[=+\-@]/.test(nv) ? "'" + nv : nv);
    row[c - 1] = nv;
  });
  var p = m ? (m.potvrdeno ? 'potvrđena' : 'nije potvrđena') : 'nema';
  if (str_(row[agC_('pristupnica') - 1]) !== p) {
    agPristupnica_(sh.getRange(r, agC_('pristupnica')), p);
    row[agC_('pristupnica') - 1] = p;
  }
  agBox_(sh, r, row, 'clanarina', !!(m && m.godine[year]));
  agBox_(sh, r, row, 'iskaznica', !!(m && m.iskaznica));
  var drop = /^(nije član – |više članova s tim imenom)/;
  if (m) agNote_(sh, r, row, '', drop);
  else agNote_(sh, r, row, f.more ? 'više članova s tim imenom – upiši OIB ili e-mail' : 'nije član – treba ispuniti pristupnicu', drop);
}

/** Promijenjeno ime ili prezime u redu: zamjena (red sa stranice) ili nova osoba (ručno). */
function agRename_(sh, ix, r, mi, year, oldValue, col) {
  var row = ix.data[r - 1], info = ix.info[r] || {}, name = agName_(row);
  if (info.kind === 'P' && info.orig === undefined) {
    // Stariji red bez zapisanog izvornog imena: iz prethodne vrijednosti ćelije.
    info.orig = oldValue === undefined ? '?' : (col === agC_('ime') ? str_(oldValue) + ' ' + str_(row[2]) : str_(row[1]) + ' ' + str_(oldValue)).trim();
    sh.getRange(r, AG_KEY_COL).setValue('P|' + info.pkey + '|' + info.orig.replace(/\|/g, ' '));
  }
  if (!info.kind) {
    info = { kind: 'M' };
    sh.getRange(r, AG_KEY_COL).setValue('M|');
  }
  ix.info[r] = info;
  agBoxes_(sh, r, row);
  var same = info.kind === 'P' && info.orig !== '?' && agNorm_(info.orig) === agNorm_(name);
  var f = memFind_(mi, row, true);
  if (!same || f.m) agApply_(sh, r, row, f, year, true);
  if (info.kind === 'P') {
    var ph = /^\d+\. osoba/.test(info.orig);
    agNote_(sh, r, row, same || ph ? '' : 'zamjena za ' + (info.orig === '?' ? 'osobu s prijave' : info.orig), /^zamjena za /);
  }
}

/** Stanje uplate i otkazivanja po narudžbi: [{o, paid, cancel, rows: [{k, n, f, x}]}]. */
function agPaid_(sh, only, ix) {
  ix = ix || agIndex_(sh);
  var pc = agC_('uplaceno') - 1, xc = agC_('otkazao') - 1, by = {};
  ix.data.forEach(function (row, i) {
    var info = ix.info[i + 1];
    if (!info || !info.o || (only && !only[info.o])) return;
    var o = by[info.o] = by[info.o] || { o: info.o, paid: true, cancel: true, rows: [], n: 0 };
    var x = row[xc] === true;
    o.rows.push({ k: info.pkey, n: agName_(row), f: info.orig && info.orig !== '?' ? info.orig : '', x: x });
    if (x) return;
    o.cancel = false;
    o.n++;
    if (row[pc] !== true) o.paid = false;
  });
  return Object.keys(by).map(function (k) {
    var o = by[k];
    if (!o.n) o.paid = false;
    delete o.n;
    return o;
  });
}

/** Ručno dodane osobe i zamjene u nadolazećim izletima: podaci i stanje iz tablice članova. */
function agLocalRefresh_(sh, ix, mi) {
  ix = ix || agIndex_(sh);
  var from = new Date(Date.now() - 10 * 864e5).toISOString().substring(0, 10), n = 0;
  ix.blocks.forEach(function (b) {
    if (!b.date || b.date < from.substring(0, b.date.length)) return;
    var br = agBlockRows_(ix, b), year = agYear_(b);
    for (var r = br.first; r <= br.end; r++) {
      if (!agIsLocal_(ix, r) || agName_(ix.data[r - 1]) === '') continue;
      mi = mi || memIndex_();
      agApply_(sh, r, ix.data[r - 1], memFind_(mi, ix.data[r - 1], false), year, false);
      n++;
    }
  });
  return n;
}

/**
 * Okidač u tablici za agenciju: Ime/Prezime (zamjena ili nova osoba), OIB/E-mail (traži
 * člana), Uplaćeno i Otkazao (javi stranici stanje tih narudžbi).
 */
function agNaIzmjenu_(e, sh) {
  var c0 = e.range.getColumn(), c1 = e.range.getLastColumn();
  var hit = function (k) { var c = agC_(k); return c >= c0 && c <= c1; };
  var name = hit('ime') || hit('prezime'), ids = hit('oib') || hit('email'), pay = hit('uplaceno'), cx = hit('otkazao');
  if (!name && !ids && !pay && !cx) return;
  var lock = LockService.getScriptLock();
  lock.waitLock(25000);
  var list = [];
  try {
    agMigrate_(sh);
    var ix = agIndex_(sh), mi = name || ids ? memIndex_() : null, blocks = {}, orders = {};
    var r0 = Math.max(2, e.range.getRow()), r1 = Math.min(e.range.getLastRow(), ix.last);
    var single = r0 === r1 && c0 === c1;
    for (var r = r0; r <= r1; r++) {
      var info = ix.info[r] || {};
      if (info.kind === 'T' || info.kind === 'H' || !agIsPerson_(ix, r)) continue;
      var b = agBlockOf_(ix, r);
      if (!b) continue;
      blocks[b.key] = b;
      var row = ix.data[r - 1];
      if (name && agName_(row) !== '') agRename_(sh, ix, r, mi, agYear_(b), single ? e.oldValue : undefined, c0);
      else if (ids && agIsLocal_(ix, r)) agApply_(sh, r, row, memFind_(mi, row, false), agYear_(b), false);
      var x = row[agC_('otkazao') - 1] === true;
      if (cx) agGrey_(sh, r, x);
      if (pay && x && row[agC_('uplaceno') - 1] === true) agNote_(sh, r, row, 'otkazano – uplata se ne računa', null);
      info = ix.info[r] || {};
      if (info.o) orders[info.o] = 1;
    }
    Object.keys(blocks).forEach(function (k) { agNumber_(sh, ix, blocks[k]); agCount_(sh, ix, blocks[k]); });
    if (Object.keys(orders).length) list = agPaid_(sh, orders, ix);
  } finally {
    lock.releaseLock();
  }
  if (list.length) post_({ ag: list });
}
