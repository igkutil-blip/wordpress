=== Plan A članstvo ===
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.15.9
License: GPLv2 or later

Pristupnica za članstvo u udruzi Plan A, potvrda klikom u e-mailu, 2D kod za članarinu,
automatski upis u Google tablicu i provjera članstva pri prijavi na izlet.

== Postavljanje ==

1. Instaliraj i aktiviraj dodatak.
2. Na stranici /pristupnica/ obriši sav stari sadržaj i stavi samo [plan-a-pristupnica]
   u Flatsome HTML blok (stranica se složi sama).
3. Članovi → Postavke i tablica: slijedi upute za Google tablicu (skripta, Deploy, URL),
   klikni "Provjeri vezu" pa "Pošalji sve članove u tablicu".
4. SpeedyCache: izuzmi adrese s parametrima potvrda i pristupnica (npr. /uclanjenje/?potvrda=…).

== Kako radi ==

1. Član ispuni pristupnicu (OIB i datum se provjeravaju, za mlađe od 18 polja za roditelja).
2. Stiže e-mail s gumbom "Potvrđujem pristupnicu". Klik otvara stranicu "Pristupnica je
   potvrđena!" (potvrda se šalje sama s te stranice, pa je ne potvrđuju programi koji u pošti
   provjeravaju poveznice).
3. Nakon potvrde stiže e-mail s podacima za članarinu i 2D kodom na račun udruge.
4. Svaka pristupnica i potvrda sama se upisuje u Google tablicu (stupci, Status, Datum
   potvrde). Stupce "Članarina GGGG" s kvačicama ispunjavate ručno; stranica ih ne dira.
5. Nepotvrđeni dobiju jedan podsjetnik 3 dana nakon e-maila za potvrdu. Nikad se ne brišu sami:
   ostaju sa statusom "Čeka potvrdu".
6. Pri prijavi na izlet e-mail kupca uspoređuje se s potvrđenim pristupnicama. Ako ga nema,
   kupac na stranici "Hvala" i u e-mailu dobiva poveznicu na pristupnicu, a u narudžbama piše
   "Član: ne". Prijava se ne blokira.

Zaštita: podatke vide samo administratori; skriveno polje i ograničenje po IP adresi protiv
botova; poveznica za potvrdu je nasumična i vrijedi 7 dana; GDPR izvoz i brisanje po e-mailu.

== Promjene ==

= 1.15.9 =
* Tablica za agenciju: kad se objavljenom izletu promijeni datum, prazni blok starog datuma sam se obriše (skripta v22, radnja ag_drop; blok u kojem je netko upisan ostaje). Prije su ostajali blokovi za svaki datum (Tinder i planinarenje 3 puta).
* Stavka izleta bez termina (narudžba od 0 € s isteklim kodom obrasca, #9115) više ne ide u tablicu – prije je nastajao blok bez datuma.
* Skripta v22: u tablicu članova (i tablicu za agenciju) zalijepiti novu skriptu i objaviti kao New version.

= 1.15.8 =
* Skripta tablice v21: lista čekanja (plan-a-prijave 0.8.0) – žuti redovi „LISTA ČEKANJA” ispod sudionika izleta (Č1, Č2 …), ne broje se u prijavljene, popis za vodiča ni sažetak; u naslovu bloka „lista čekanja N”; ne idu u arhivu.

= 1.15.7 =
* Skripta tablice v20: narudžba s više osoba ima svoju boju i na kućicama „Uplaćeno” (prva rata) i „2. rata”, ne samo na broju narudžbe.

= 1.15.6 =
* Skripta tablice v19: u tablici za agenciju novi stupac „Iznos 2. rate” iza „Iznos” (prvi red narudžbe s prvom ratom: ostatak = puna cijena − prva rata, osiguranje se ne oduzima). Postojeća tablica (i Arhiva) dobije stupac sama, a iznose za već upisane narudžbe upiše stranica pri sljedećem osvježavanju.

= 1.15.5 =
* Skripta tablice v18: osoba koju ste ručno dodali u tablicu za agenciju dobiva u Napomeni „unesen ručno” (i već dodane, pri sljedećem osvježavanju). Ostatak napomene ostaje.

= 1.15.4 =
* VAŽNO: uplatnica i 2D kod za drugu ratu glase na agenciju (primatelj, IBAN, model i poziv na broj kao na uplatnici za prijavu, iz dodatka WSB HUB3), ne na udrugu. Račun udruge je samo za članarinu. Bez podataka agencije mail nema uplatnicu, nego uputu da se plati kao prva rata.
* Siječanjski mail: „želimo ti sretnu Novu godinu”. „Cjelokupni iznos” (pravopis).

= 1.15.3 =
* Izvještaji pregledni i na mobitelu: dnevni pregled (izleti s brojkama u stupcima i upozorenjima kao oznakama, isti zapisi jednom s brojem ×), popis za vodiča (svaki sudionik u svom retku s mobitelom i stanjem), neplaćena članarina i druga rata (bez širokih tablica).

= 1.15.2 =
* Prava uplatnica HUB-3A kao slika (isti izgled kao u mailu narudžbe, s 2D kodom) u mailovima za drugu ratu i članarinu. Ako dodatak WSB HUB3 nije instaliran, ostaje uplatnica u HTML-u.

= 1.15.1 =
* Ikona iznad naslova maila je okrugla slika (u Gmailu na mobitelu se krug više ne razvlači u elipsu), ista u svim mailovima. Mail o otkazivanju: bez obećanja povrata – s osiguranjem od otkaza kupac se obraća osiguranju, inače agencija ne vraća uplatu.

= 1.15.0 =
* Svi mailovi (pristupnica, članarina, prva i druga rata, otkazivanje, dnevni pregled, popis za vodiča, neplaćena članarina, upozorenja) u zajedničkom Plan A izgledu. Mailovi s plaćanjem imaju 2D kod u samom mailu i uplatnicu (HUB-3A); kod druge rate i pregled: puna cijena, uplaćena prva rata, osiguranje (ne ulazi u ostatak) i ostatak.

= 1.14.8 =
* Mail s ostatkom za drugu ratu (i podsjetnik): 2D kod je ugrađen u sam mail, pa se vidi u tekstu (do sada je slika na stranici obrisana odmah nakon slanja, pa se u mailu nije prikazivala, nego samo kao privitak).

= 1.14.7 =
* Kvačica „Otkazao” u tablici agencije: kupac dobiva mail o otkazivanju (cijela prijava ili pojedini sudionik), a za pojedinog sudionika i mi kopiju (za cijelu narudžbu nama i dalje javlja WooCommerce). Ako je bilo uplaćeno, u mailu piše da ćemo se javiti oko povrata.
* Osiguranje u tablici agencije kod svake osobe koja ga je uzela (do sada samo kod prve u prijavi), pa i „Polica” i dnevni pregled broje točno.
* Zamjena „ime, pa prezime” bilježi se jednom (bez međukoraka) u bilješkama narudžbe i dnevnom pregledu.
* Vraćanje narudžbe iz tablice (npr. maknuta kvačica „Otkazao”) više ne šalje nama mail „Nova prijava”.

= 1.14.6 =
* Druga rata: ostatak se računa po osobi s kartom „Uplata prve rate” (puna cijena − prva rata). Osiguranje i druge usluge plaćene uz prvu ratu više se ne odbijaju.
* Ispravak: puna cijena izleta čita se iz ispravnog polja karte – do sada je ostatak ispadao 0 € pa mail s drugom ratom nije odlazio.
* Narudžbama kojima taj mail zbog greške nije otišao, a izlet još nije prošao, mail se jednom ponovno pošalje.

= 1.14.5 =
* Isključena „2. rata” više nije crna nego diskretno svijetlo siva. Postojeće crne ćelije se same prebojaju pri sljedećem osvježavanju. Ništa drugo se ne mijenja.

= 1.14.4 =
* Popravak: kućica „2. rata” ide po izletu, ne po osobi. Na izletu s dvije rate ima je svaka osoba (i oni koji su odmah platili sve, njima cure označe obje kvačice), na ostalim izletima ćelija je crna.
* Izlet s dvije rate prepoznaje se po karti „Uplata prve rate” na izletu i po narudžbama s prvom ratom.
* Skripta v17.

= 1.14.3 =
* Gumb „Osvježi tablicu za agenciju” odmah uredi kućice „2. rata” i javi koje izlete s dvije rate je prepoznao.

= 1.14.2 =
* Popravak: kućica „2. rata” bila je kod svih izleta jer je Google pri umetanju stupca kopirao kvačice iz susjednog stupca „Uplaćeno”. Sada je kućica samo na izletima s kartom „Uplata prve rate” (osobe koje su platile prvu ratu). Na ostalim izletima ćelija je crna i ne prima upis.
* Iz naziva stupaca i praznih redova maknute su naslijeđene kućice („2. rata”, „Ugovor”, „Polica”).
* Stranica dvije rate prepoznaje samo kod narudžbi s prvom ratom. Obične narudžbe s kvačicom „Uplaćeno” koje su zbog greške ostale „U obradi” same prelaze u „Završeno” (kupac dobiva uobičajeni e-mail).
* Skripta v16.

= 1.14.1 =
* Kućica „Polica” je aktivna (bijela) kad je u stupcu „Osiguranje” označeno, inače siva. Osiguranje ostaje kako je bilo i može se označiti i ručno.

= 1.14.0 =
* Tablica agencije: dva nova stupca, „Ugovor” (po osobi) i „Polica” (samo za osobe s osiguranjem). Kad su gotovi, cure ih označe.
* Dnevni pregled (vama, agenciji i blagajniku): za izlete u sljedećih 30 dana stupci „ugovor X od Y” i „polica X od Y”, te oznake „ugovor nije poslan” i „polica nije izdana”.
* Stara tablica se sama nadopuni novim stupcima. Skripta v15.

= 1.13.5 =
* Dnevni pregled (vama, agenciji i blagajniku): uplate pišu „Prva rata uplaćena” ili „Cijelokupni iznos uplaćen”, u tablici izleta vidi se stanje 2. rate, a novi odjeljak „Druga rata još nije uplaćena” s iznosom ostatka.
* Krešin mjesečni popis: isti odjeljak za drugu ratu. Popis za vodiča: „1. rata” za one koji nisu platili drugu ratu. Skripta v14.

= 1.13.4 =
* Mail o prvoj rati glasi „Uplaćena prva rata”. Mail o cijelom iznosu (uključujući završetak nakon druge rate) glasi „Cijelokupni iznos je uplaćen”. Zahtijeva plan-a-kosarica 1.5.5.

= 1.13.3 =
* Mail s ostatkom nakon prve rate šalje se tek sat vremena nakon kvačice „Uplaćeno”. Ako u tom roku stigne i „2. rata” (kupac je platio sve), narudžba se završi i kupac dobije samo mail o završetku.

= 1.13.2 =
* Mail s ostatkom i podsjetnik za drugu ratu nose 2D kod s točnim iznosom ostatka. Ako kod ne uspije, mail se šalje s iznosom i pozivom na broj bez koda (nikad zajednički kod članarine).
* Podsjetnik za drugu ratu ide 35 dana prije izleta (rok je 30 dana prije), jednom. Ako je prva rata uplaćena u tom roku, podsjetnik se ne šalje.

= 1.13.1 =
* Jednokratno: otvorene narudžbe izleta s dvije rate dobe stupac „2. rata” u tablici agencije.

= 1.13.0 =
* Izleti s dvije rate: prva rata prepoznaje se po karti „Uplata prve rate” u narudžbi. U tablici agencije novi stupac „2. rata” (samo za te izlete). „Uplaćeno” znači prvu ratu, a narudžba je završena kad su označene obje rate.
* Nakon prve rate kupac dobiva mail s ostatkom (puna cijena minus prva rata), rokom (30 dana prije izleta) i uplatnicom s iznosom ostatka i brojem narudžbe kao pozivom na broj.
* Podsjetnik za drugu ratu 30 dana prije izleta (jednom), s uplatnicom za ostatak.
* Narudžba je „U obradi” nakon prve rate, a „Završeno” kad je i druga rata označena. Skripta v13.

= 1.12.2 =
* Popis za vodiča: posebni stupci Pristupnica (da / nepotvrđena / NE) i Članarina (da / NE), crveno označeno što nedostaje, te okvir „Na izletu treba riješiti” (tko treba ispuniti ili potvrditi pristupnicu i platiti članarinu), i u e-mailu i u PDF-u.

= 1.12.1 =
* Siječanjski e-mail za članarinu ide svim potvrđenim članovima koji još nisu platili, s poveznicom za odjavu; odjavljeni ga više ne dobivaju (mogu se vratiti istom poveznicom). Broj odjavljenih je u okviru Stanje sustava.

= 1.12.0 =
* Popis za vodiča: novi stupac Iskaznica (uručena da/ne; – za one koji nisu članovi).
* Popis neplaćenih za blagajnika (siječanj–travanj) sadrži samo članove koji su prijavljeni na izlete. Skripta v12.

= 1.11.1 =
* Dnevni pregled i kopija svakog podsjetnika za uplatu idu i blagajniku. Upozorenja o vezi s tablicom idu samo vama.

= 1.11.0 =
* Podsjetnik za uplatu: kupac s uplatnicom dobije jedan podsjetnik (isti podaci i 2D kod) 5 dana nakon narudžbe bez uplate ili 3 dana prije izleta; u tablici agencije u Napomeni piše „podsjetnik poslan”.
* Dnevni pregled u 7 sati (vama i agenciji): nove prijave, uplate, otkazivanja, zamjene, podsjetnici i izleti u sljedećih 30 dana (skoro pun, nitko nije platio).
* Popis sudionika vodičima dan prije izleta u 8 sati (PDF za print), prema polju Vodiči u Planu izleta; vama kopija.
* Siječanj: e-mail s uplatnicom i 2D kodom za članarinu nove godine (2. siječnja, 50 na sat) i popis neplaćenih blagajniku prvog u mjesecu (siječanj–travanj).
* Tablica agencije: izleti stariji od 30 dana sele na list „Arhiva”, a 12 mjeseci nakon izleta brišu se OIB, datum rođenja, adresa i mobitel; stupci koje puni web zaštićeni su upozorenjem (i u tablici članova).
* Upozorenje e-mailom kad veza s Google tablicom ne radi (i kad opet proradi ili je skripta stara) te okvir „Stanje sustava” u postavkama. Skripta v11.

= 1.10.0 =
* Tablica za agenciju – povezane osobe iz iste narudžbe (skripta v10): u stupcu Narudžba piše npr. „#1234 · 3 osobe · 2 izleta”, ćelija ima boju narudžbe (ista u svim izletima), a bilješka (prelazak mišem) pokazuje tko je platio, ukupni iznos i sve izlete s osobama.

= 1.9.0 =
* Tablica za agenciju – kvačice i upisi odmah mijenjaju narudžbe (skripta v9):
  * Uplaćeno: kad su označeni svi koji idu na izlet, narudžba postaje „Završeno” i kupac dobiva e-mail „Uplata je zaprimljena, vidimo se na izletu”. Maknuta kvačica vraća narudžbu na čekanje bez e-maila.
  * Novi stupac Otkazao: red posivi, a otkazivanje se upiše u bilješke narudžbe. Kad otkažu svi iz narudžbe, narudžba se otkazuje i e-mail ide samo vama. Maknuta kvačica vraća prijašnji status bez e-maila. Postojeća tablica stupac dobije sama, a sivi redovi kvačicu.
  * Zamjena: novo ime i prezime u istom redu. Ostali podaci, Pristupnica, Članarina i Iskaznica upišu se iz tablice članova, u Napomenu „zamjena za …”, a u bilješke narudžbe „Zamjena: … umjesto …”.
  * Ručno dodana osoba (novi red): broj i podaci iz tablice članova. Kad ima više članova s istim imenom, traži se OIB ili e-mail. Takvi redovi se osvježavaju kad se promijene kvačice u tablici članova i svaki sat.
  * Brojevi (Br.) slažu se ispočetka kad se red doda ili obriše.
  * Kartično plaćene i na stranici otkazane narudžbe se ne diraju. Stranica više ne briše kvačicu „Uplaćeno” kod neplaćenih narudžbi.

= 1.7.0 =
* Brzo osvježavanje: tablica članova javlja stranici čim se označi kvačica za članarinu ili iskaznicu (okidač u Apps Scriptu, funkcija ukljuciBrzoOsvjezavanje), a stranica odmah osvježi tablicu za agenciju. Skripta v7.

= 1.6.10 =
* E-mail kupcu: narančasti okvir "Potvrdi svoju pristupnicu" s gumbom na vrhu e-maila dok pristupnica čeka potvrdu.

= 1.6.9 =
* OIB: jasnija poruka (kontrolna znamenka) i provjera odmah ispod polja u košarici.

= 1.6.8 =
* "Trebam R1 račun": kad je označeno, polja R1 računa (naziv tvrtke, adresa, OIB) su obavezna (zvjezdica i provjera prije slanja).
* Provjera e-maila čeka da se upiše do kraja.

= 1.6.7 =
* Pristupnica u košarici: što donosi članstvo, iznos članarine i koraci (potvrda u e-mailu, 2D kod za članarinu, iskaznica).

= 1.6.6 =
* Sigurnost: podaci upisani iz pristupnice ne ostaju zapamćeni u košarici posjetitelja nakon narudžbe.
* Jasnija poruka za nepotvrđenu pristupnicu u košarici.

= 1.6.5 =
* Prazan okvir za poruku kod ostalih sudionika više se ne vidi.

= 1.6.4 =
* "Ostali sudionici" odmah ispod podataka kupca (iznad napomene).
* Isti izlet više puta u košarici: kupac se broji jednom, ostale osobe redom (npr. 1 + 2 osobe = kupac i još dvije).

= 1.6.3 =
* E-mail je prvi i kad drugi dodatak mijenja redoslijed polja; članu se skrivaju samo polja iz pristupnice te tvrtka i dodatak adrese (npr. "Trebam R1 račun" ostaje).

= 1.6.2 =
* Poruka nakon radnje prenosi se i u adresi stranice (potpisano); uz naslov se vidi broj verzije.

= 1.6.1 =
* Poruke nakon radnji (Provjeri vezu, uvoz, osvježavanje …) ispisuju se izravno na stranici dodatka, da ih drugi dodaci ne sakriju.

= 1.6.0 =
* Članstvo u košarici (Postavke → "Članstvo u košarici"): e-mail je prvo polje i prepoznaje člana (podaci iz pristupnice upisuju se na poslužitelju, u preglednik se ne šalju); nečlan ispunjava pristupnicu u košarici (Čeka potvrdu, gumb za potvrdu u e-mailu o narudžbi); za više osoba traže se ostali sudionici (nečlanovi dobivaju svoj e-mail za potvrdu); članarina se provjerava za godinu izleta i šalje se e-mail s 2D kodom (jednom po godini).
* Blok "Članstvo Plan A" u e-mailu kupcu i na stranici "Hvala"; stara narančasta napomena je uklonjena.
* Tablica za agenciju "Prijave na izlete": jedan list, blok po izletu (novi na vrhu), osoba po redu sa svim podacima; svaka osoba se upisuje jednom (obrisani red se ne vraća); Uplaćeno, Pristupnica, Članarina i Iskaznica se osvježavaju. Početni popis iz CSV-a.
* Skripta u tablici v6 (potrebno kopirati i objaviti novu verziju te jednom pokrenuti "ovlasti").

= 1.5.1 =
* Blok "Članstvo Plan A" u e-mailu "Nova narudžba": pristupnica, članarina za godinu izleta, iskaznica; za kupca bez pristupnice moguće podudaranje po imenu.

= 1.5.0 =
* Stranica svaki sat čita kvačice "Članarina GGGG" i "Iskaznica uručena" iz tablice (i gumb "Osvježi kvačice iz tablice"). Potrebna nova skripta (v5).

= 1.4.0 =
* Gumb "Poredaj brojeve po datumu prijave" (Članovi → Uvoz članova): Br. redom po datumu prijave, na stranici i u tablici; kvačice idu sa svojim redom.
* Uvoz ažurira datum prijave i potvrde i postojećim članovima.
* Potrebno: nova skripta u tablici (v4) – kopirati i objaviti kao New version.

= 1.3.5 =
* Ispravak: veći paketi za tablicu dobivali su od Googlea HTTP 400. Preusmjeravanje Google skripte sada se otvara kao GET.

= 1.3.4 =
* "Pošalji neposlane u tablicu" i "Pošalji sve članove" rade s trakom napretka, paket po paket.
* "Provjeri vezu" javlja je li u tablici stara skripta; uz staru ili sporu skriptu šalje se u malim paketima.

= 1.3.3 =
* Skripta u tablici upisuje cijeli paket odjednom (prije red po red), pa slanje više ne istekne.
  Potrebno: kopirati novu skriptu u tablicu i objaviti novu verziju.

= 1.3.2 =
* Uvoz ide u dijelovima s trakom napretka (ne prekida ga vremensko ograničenje poslužitelja) i nastavlja gdje je stao.
* Na stranici uvoza vidi se broj članova i rezultat zadnjeg uvoza.

= 1.3.1 =
* Uvoz članova je zasebna stavka izbornika: Članovi → Uvoz članova.

= 1.3.0 =
* Uvoz članova iz CSV-a (Postavke i tablica → 4. Uvoz članova). Uvoz ne šalje e-mailove i ne duplira članove.
* Stupac "Napomena" u tablici (iza "Iskaznica uručena"); popunjava se samo pri uvozu i samo ako je prazan.
* Slanje u tablicu ide u paketima; gumb "Pošalji neposlane u tablicu" nastavlja gdje je stalo.
* Potrebno: kopirati novu skriptu u tablicu i objaviti novu verziju (Deploy → Manage deployments → Edit → New version).

= 1.2.2 =
* Nepotvrđene pristupnice se nikad ne brišu same; ostaju sa statusom "Čeka potvrdu".
  Podsjetnik se može isključiti (0 dana).

= 1.2.1 =
* Podsjetnik i brisanje nepotvrđenih računaju se od e-maila za potvrdu, ne od datuma prijave;
  uvezeni članovi koji još nisu dobili e-mail ostaju netaknuti.
* Skupna radnja u popisu članova: "Pošalji e-mail za potvrdu (nepotvrđenima)".

= 1.2.0 =
* Google tablica: stupac "Iskaznica uručena" s kvačicama, uvijek na kraju (stupac za novu godinu
  članarine dodaje se ispred njega). Kvačice se označavaju ručno; pri uvozu se popune iz starih tablica.
  Postojeću skriptu treba zamijeniti novom i objaviti novu verziju (Manage deployments → Edit → New version).

= 1.1.3 =
* Ista osoba se ne duplira: isti OIB, ili (kod krivo upisanog OIB-a) isti e-mail, ime i datum
  rođenja. Djeca s roditeljskim e-mailom ostaju zasebni članovi.

= 1.1.2 =
* E-mailovi se šalju s adrese pošiljatelja iz WooCommercea (npr. info@srd-plan-a.hr) umjesto
  wordpress@…, koju poslužitelji pošte često odbace. Gumb "Pošalji mi probni e-mail" i zapis
  zadnjeg poslanog e-maila u Postavkama.

= 1.1.1 =
* Poveznica za potvrdu i napomena na naplati vode na objavljenu stranicu sa shortcodeom
  (npr. /pristupnica/), i prije nego je itko otvori.
* Provjera članstva pri prijavi na izlet zadano je isključena; uključi je u Postavkama nakon
  uvoza postojećih članova (inače bi svi kupci dobili napomenu da nisu članovi).

= 1.1.0 =
* [plan-a-pristupnica] prikazuje cijelu stranicu: uvod s pogodnostima i članarinom, "Kako postati
  član" u tri koraka i obrazac. Na računalu dva stupca, na mobitelu jedno ispod drugog s gumbom
  "Ispuni pristupnicu". Tekstovi se uređuju u Postavkama. Samo obrazac: [plan-a-pristupnica izgled="obrazac"].

= 1.0.0 =
* Prva inačica.
