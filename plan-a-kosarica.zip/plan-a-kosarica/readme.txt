=== Plan A košarica ===
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.6.3
License: GPLv2 or later

Novi izgled košarice, stranice za plaćanje, završne stranice narudžbe i e-mailova kupcu
(WooCommerce) za izlete iz WpTravellyja.

== Opis ==

* koraci Košarica → Podaci → Plaćanje (na plaćanju se korak "Plaćanje" označi kad
  se dođe do načina plaćanja),
* košarica: kartica izleta sa slikom, nazivom, mjestom (ili državom), datumom i vremenom,
  brojem sudionika po vrsti karte, cijenom po osobi, dodatnim uslugama i smještajem;
  ikona za uklanjanje; "Imaš kod za popust?"; sažetak rezervacije s retcima karata i
  usluga, kuponima, naknadama, porezima i iznosom "Ukupno za uplatu"; gumb
  "Nastavi na plaćanje"; "Pogledaj još izleta" i "Trebaš pomoć? Javi nam se" (WhatsApp);
  gumb teme "Nastavite kupnju" postaje sekundarni gumb "Nastavi s odabirom izleta" (vodi na
  adresu "Pogledaj još izleta", zadano /izleti/),
* prazna košarica (1.2.0): ikona ruksaka, "Tvoja košarica je prazna", gumb "Pogledaj izlete"
  (adresa "Pogledaj još izleta", zadano /izleti/), "Najbliži izleti" (shortcode
  [plan-a-izleti show="3" all_url="/izleti/"], samo ako je aktivan Plan A izleti) i poveznica
  "Javi nam se na WhatsApp" (broj iz postavki, zadano 385959060556); bez koraka; ispod
  "Pogledaj izlete" kuka plan_a_kosarica_empty_actions za dodatne gumbe (1.2.1, npr. "Daruj
  poklon bon" iz dodatka Plan A poklon bon),
* polje za kod (1.4.0): istaknuti okvir "Imaš kod za popust?" s uputom, poljem i gumbom
  "Iskoristi" u sažetku košarice i u "Tvoja rezervacija" na naplati, odmah iznad "Ukupno za
  uplatu"; kod se primjenjuje bez slanja obrasca, poruka je ispod polja; zadana poveznica
  "Imate kupon?" na vrhu naplate i staro polje ispod stavki košarice se ne prikazuju;
  polje i gumb uvijek u istom redu unutar okvira i uz stilove teme (1.4.1),
* plaćanje: gumb "Povratak u košaricu", kraći tekst u polju napomena, kartice "Podaci kupca" i "Napomena", "Tvoja rezervacija"
  (slika, mjesto, datum, sudionici, retci cijene, ukupno) i "Način plaćanja",
* na računalu dva stupca (sadržaj i sažetak), na mobitelu jedan; prilagođava se širini
  sadržaja teme.

Ništa se ne izostavlja: predlošci zadržavaju sve kuke i filtre WooCommercea, polja drugih
dodataka, kupone, naknade, poreze, dostavu (ako postoji) i sve načine plaćanja. Podaci
WpTravellyja (blok "Booking Details") prikazuju se strukturirano, a kuke WpTravellyja za
dodatke (npr. podaci o sudionicima) i dalje se ispisuju. Obični proizvodi (ne izleti) imaju
polje za količinu i gumb "Ažuriraj košaricu".

Zamijenjeni predlošci WooCommercea (i teme, npr. Flatsome):
cart/cart.php, cart/cart-empty.php, cart/cart-totals.php, cart/proceed-to-checkout-button.php,
checkout/form-checkout.php, checkout/review-order.php.
Od verzije 1.1.0 i: checkout/thankyou.php, emails/customer-on-hold-order.php,
emails/customer-processing-order.php, emails/customer-completed-order.php.
"Moj račun", e-mailovi administratoru i e-mailovi u obliku običnog teksta se ne mijenjaju.

== Završna stranica i e-mailovi (1.1.0) ==

* koraci Košarica → Podaci → Prijava završena, zelena kvačica, "Hvala, [ime]! Vaša prijava
  je zaprimljena." i broj narudžbe,
* "Što sada?" s tri koraka (uređuju se u postavkama); kod plaćanja karticom prvi korak je
  "Plaćanje je uspješno" i nema bloka za plaćanje,
* "Podaci za plaćanje": 2D kod (HUB3) i podatke za uplatu i dalje ispisuje postojeći dodatak
  za uplatnicu; ovaj dodatak ih ne mijenja, samo kod premješta na vrh bloka (pune širine na
  mobitelu) s natpisom "Skenirajte i platite". Rok plaćanja ispisuje se samo ako je upisan
  u postavkama,
* "Vaš izlet" (izlet, datum, lokacija, broj osoba, cijena, dodatno, ukupno, bilješka),
  "Vaši podaci" i gumb "Predloži ekipi" (ako je aktivan Plan A izleti),
* e-mailovi istog sadržaja: tamnoplavo zaglavlje s logotipom, širina do 600 px;
  "Uplata je zaprimljena, vidimo se na izletu" nakon uplate (bez bloka za plaćanje),
* gumb "Pošalji probni e-mail" u postavkama šalje oba e-maila za zadnju narudžbu na adresu
  administratora.

Usklađeno s dodatkom WSB HUB3 (Branko Borilović): njegov barkod (slika alt="barcode")
prikazuje se na vrhu bloka i na stranici i u e-mailu (ugrađene slike cid: ostaju kakve jesu),
ispod je njegova uplatnica HUB-3A i tekst; gumb "Prikaži veći barkod" se skriva jer je kod
uvijek vidljiv. Ako je u WSB HUB3 odabran prikaz bez teksta (samo uplatnica ili samo
barkod), ispod se dodaju podaci za ručnu uplatu koje ispisuje sam WSB HUB3.

Ako dodatak za uplatnicu u e-mail ne ispisuje podatke za ručnu uplatu kao tekst, e-mail
sadrži poveznicu na stranicu narudžbe s tim podacima.

== E-mail vama: Nova narudžba (1.5.0) ==

E-mail "Nova narudžba" ima isti izgled kao e-mailovi kupcu: izlet, ukupno i je li plaćeno, kupac
(mobitel i e-mail su poveznice), blok "Članstvo Plan A" (puni ga dodatak Plan A članstvo preko
filtra plan_a_kosarica_member_rows) i gumb "Otvori narudžbu". Naslov: "Nova prijava #… – kupac – izlet".

== Članstvo na stranici "Hvala" (1.5.1) ==

Blok "Članstvo Plan A" (filtar plan_a_kosarica_member_rows, način 'thankyou'); podaci kupca upisani iz pristupnice
ne prikazuju se (filtar plan_a_kosarica_hide_customer_details).

== Isti izlet više puta (1.5.2) ==

Izlet se može dodati u košaricu više puta (WooCommerce inače javlja "Ne možete dodati još jedan …");
svaka prijava je zasebna stavka, a sudionici se zbrajaju.

== Povratak na izlet (1.5.3) ==

Kad se kupac tipkom "Natrag" vrati na stranicu izleta, stranica se osvježi (inače gumb za rezervaciju ostane u stanju učitavanja).

== Obavijest na vrhu e-maila (1.5.5) ==

Filtar plan_a_kosarica_email_notice: HTML u narančastom okviru ispod naslova e-maila kupcu (npr. potvrda pristupnice).

== Isti izgled svih mailova (1.6.0) ==

Zajednički Plan A izgled maila (Plan_A_Email, ista datoteka u svim Plan A dodacima): i svi ostali
WooCommerceovi mailovi (otkazana narudžba, povrat, napomena kupcu, lozinka, novi račun, poklon bon …)
dobivaju isto zaglavlje s logom, naslov s ikonom, karticu i podnožje (predlošci email-header.php i
email-footer.php).

== Okrugla ikona (1.6.1) ==

Ikona iznad naslova maila je okrugla slika (u Gmailu na mobitelu se krug više ne razvlači u elipsu), ista u svim mailovima.

== Uređeni ostali mailovi (1.6.2) ==

Otkazana narudžba, povrat, napomena kupcu, račun: umjesto WooCommerceove tablice (sa sličicama
proizvoda i uskim stupcima) isti sažetak kao u mailu „Prijava zaprimljena” (kartice „Vaš izlet”
i „Vaši podaci”). Uplatnica i 2D kod (WSB HUB3) samo u mailu „Prijava zaprimljena” i u računu.
Slike u mailovima nikad nisu šire od kartice (i na mobitelu).

== Pravopis (1.6.3) ==

Naslov maila i stranice nakon uplate: „Cjelokupni iznos je uplaćen, vidimo se na izletu”.

== Postavke ==

Postavke → Plan A košarica: uključivanje, koraci (koraci teme Flatsome se tada skrivaju),
adresa "Pogledaj još izleta", WhatsApp broj za pomoć, tekst pomoći, boje; završna stranica i
e-mailovi (uključivanje, koraci "Što sada?", rok plaćanja, logotip za e-mail).

Košarica i plaćanje moraju biti klasične stranice sa shortcodeom [woocommerce_cart] i
[woocommerce_checkout] (tako ih koristi Flatsome). Ako stranica koristi WooCommerce
blokove, postavke to prikažu i novi izgled se na njoj ne koristi.

== Uklanjanje ==

Odznačite "Uključen" u postavkama ili deaktivirajte dodatak: odmah se vraća izgled teme.
Brisanje dodatka uklanja samo njegove postavke.
