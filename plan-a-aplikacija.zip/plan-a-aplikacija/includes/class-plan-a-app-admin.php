<?php
/**
 * Stranica postavki: Postavke > Plan A aplikacija.
 *
 * @package Plan_A_Aplikacija
 */

defined( 'ABSPATH' ) || exit;

final class Plan_A_App_Admin {

	const PAGE = 'plan-a-aplikacija';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( PLAN_A_APP_FILE ), array( __CLASS__, 'action_link' ) );
	}

	public static function menu() {
		add_options_page( __( 'Plan A aplikacija', 'plan-a-aplikacija' ), __( 'Plan A aplikacija', 'plan-a-aplikacija' ), 'manage_options', self::PAGE, array( __CLASS__, 'render' ) );
	}

	public static function action_link( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=' . self::PAGE ) ) . '">' . esc_html__( 'Postavke', 'plan-a-aplikacija' ) . '</a>' );
		return $links;
	}

	public static function register() {
		register_setting(
			'plan_a_app',
			Plan_A_App_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'Plan_A_App_Settings', 'sanitize' ),
				'default'           => Plan_A_App_Settings::defaults(),
			)
		);
	}

	public static function assets( $hook ) {
		if ( 'settings_page_' . self::PAGE !== $hook ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'plan-a-aplikacija-admin', PLAN_A_APP_URL . 'assets/admin.js', array( 'jquery', 'wp-color-picker' ), PLAN_A_APP_VERSION, true );
		wp_localize_script(
			'plan-a-aplikacija-admin',
			'planAAppAdmin',
			array(
				'title'  => __( 'Odaberite logotip', 'plan-a-aplikacija' ),
				'button' => __( 'Koristi ovaj logotip', 'plan-a-aplikacija' ),
			)
		);
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s     = Plan_A_App_Settings::get();
		$name  = Plan_A_App_Settings::OPTION;
		$icons = Plan_A_App_Icons::get();
		$logo  = $s['logo_id'] ? wp_get_attachment_image_url( (int) $s['logo_id'], 'medium' ) : '';
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Plan A aplikacija', 'plan-a-aplikacija' ); ?></h1>
			<?php
			$tab  = isset( $_GET['tab'] ) && 'stats' === sanitize_key( wp_unslash( $_GET['tab'] ) ) ? 'stats' : 'settings'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- samo izbor kartice.
			$base = admin_url( 'options-general.php?page=' . self::PAGE );
			?>
			<nav class="nav-tab-wrapper" style="margin-bottom:16px;">
				<a href="<?php echo esc_url( $base ); ?>" class="nav-tab<?php echo 'settings' === $tab ? ' nav-tab-active' : ''; ?>"><?php esc_html_e( 'Postavke', 'plan-a-aplikacija' ); ?></a>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'stats', $base ) ); ?>" class="nav-tab<?php echo 'stats' === $tab ? ' nav-tab-active' : ''; ?>"><?php esc_html_e( 'Statistika', 'plan-a-aplikacija' ); ?></a>
			</nav>
			<?php
			if ( 'stats' === $tab ) {
				self::render_stats();
				echo '</div>';
				return;
			}
			?>
			<p><?php esc_html_e( 'Pretvara stranicu u web aplikaciju koju posjetitelji mogu instalirati na mobitel. Košarica, plaćanje i korisnički račun nikad se ne spremaju u predmemoriju.', 'plan-a-aplikacija' ); ?></p>

			<?php self::status_notices( $icons ); ?>

			<form method="post" action="options.php">
				<?php settings_fields( 'plan_a_app' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Aplikacija', 'plan-a-aplikacija' ); ?></th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[enabled]" value="1" <?php checked( $s['enabled'] ); ?>> <?php esc_html_e( 'Uključena', 'plan-a-aplikacija' ); ?></label>
							<p class="description"><?php esc_html_e( 'Kad je isključena, service worker se kod posjetitelja sam uklanja i briše predmemoriju.', 'plan-a-aplikacija' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Logotip (ikona aplikacije)', 'plan-a-aplikacija' ); ?></th>
						<td>
							<input type="hidden" id="plan-a-logo-id" name="<?php echo esc_attr( $name ); ?>[logo_id]" value="<?php echo esc_attr( (string) $s['logo_id'] ); ?>">
							<div id="plan-a-logo-preview" style="margin-bottom:8px;">
								<?php if ( $logo ) : ?>
									<img src="<?php echo esc_url( $logo ); ?>" alt="" style="max-width:160px;max-height:160px;background:#f0f0f1;padding:8px;">
								<?php endif; ?>
							</div>
							<button type="button" class="button" id="plan-a-logo-select"><?php esc_html_e( 'Odaberi logotip', 'plan-a-aplikacija' ); ?></button>
							<button type="button" class="button-link-delete" id="plan-a-logo-remove" <?php echo $logo ? '' : 'hidden'; ?>><?php esc_html_e( 'Ukloni', 'plan-a-aplikacija' ); ?></button>
							<p class="description"><?php esc_html_e( 'Kvadratna PNG slika, najmanje 512 × 512 px. Iz nje se generiraju ikone 192 px, 512 px, maskable 512 px i ikona za iPhone (180 px).', 'plan-a-aplikacija' ); ?></p>
							<?php if ( $icons['icons'] ) : ?>
								<p style="display:flex;gap:12px;align-items:flex-end;margin-top:12px;">
									<?php foreach ( array( '192' => 64, 'maskable-512' => 96, 'apple-180' => 64 ) as $key => $px ) : ?>
										<?php if ( ! empty( $icons['icons'][ $key ] ) ) : ?>
											<span style="text-align:center;font-size:11px;">
												<img src="<?php echo esc_url( $icons['icons'][ $key ] ); ?>" alt="" width="<?php echo esc_attr( (string) $px ); ?>" height="<?php echo esc_attr( (string) $px ); ?>" style="display:block;border:1px solid #ddd;<?php echo 'maskable-512' === $key ? 'border-radius:50%;' : 'border-radius:12px;'; ?>"><?php echo esc_html( $key ); ?>
											</span>
										<?php endif; ?>
									<?php endforeach; ?>
								</p>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="plan-a-color"><?php esc_html_e( 'Boja aplikacije', 'plan-a-aplikacija' ); ?></label></th>
						<td>
							<input type="text" id="plan-a-color" class="plan-a-color" name="<?php echo esc_attr( $name ); ?>[theme_color]" value="<?php echo esc_attr( $s['theme_color'] ); ?>" data-default-color="<?php echo esc_attr( Plan_A_App_Settings::default_theme_color() ); ?>">
							<p class="description"><?php esc_html_e( 'Boja trake preglednika i aplikacije. Zadano: boja zaglavlja teme Flatsome.', 'plan-a-aplikacija' ); ?></p>
						</td>
					</tr>
					<?php
					$fields = array(
						'start_url'   => __( 'Početna adresa aplikacije', 'plan-a-aplikacija' ),
						'nav_izleti'  => __( 'Navigacija: Izleti', 'plan-a-aplikacija' ),
						'nav_plan'    => __( 'Navigacija: Plan izleta', 'plan-a-aplikacija' ),
						'nav_cart'    => __( 'Navigacija: Košarica', 'plan-a-aplikacija' ),
						'nav_contact' => __( 'Navigacija: Kontakt', 'plan-a-aplikacija' ),
					);
					foreach ( $fields as $key => $label ) :
						?>
						<tr>
							<th scope="row"><label for="plan-a-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
							<td><input type="text" class="regular-text code" id="plan-a-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $name . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( $s[ $key ] ); ?>" placeholder="<?php echo esc_attr( Plan_A_App_Settings::defaults()[ $key ] ); ?>"></td>
						</tr>
					<?php endforeach; ?>
					<tr>
						<th scope="row"><?php esc_html_e( 'Poziv na instalaciju', 'plan-a-aplikacija' ); ?></th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[install_prompt]" value="1" <?php checked( $s['install_prompt'] ); ?>> <?php esc_html_e( 'Prikaži traku „Instaliraj aplikaciju Plan A” na mobitelu', 'plan-a-aplikacija' ); ?></label>
							<fieldset style="margin:10px 0 0 24px;">
								<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[prompt_every]" value="1" <?php checked( (int) $s['prompt_every'], 1 ); ?>> <?php esc_html_e( 'Pri svakoj posjeti („Ne sada” skriva traku do sljedeće posjete; na iPhoneu na 30 dana)', 'plan-a-aplikacija' ); ?></label><br>
								<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[prompt_every]" value="0" <?php checked( (int) $s['prompt_every'], 0 ); ?>> <?php esc_html_e( 'Od druge posjete („Ne sada” skriva traku na 30 dana)', 'plan-a-aplikacija' ); ?></label>
							</fieldset>
							<p class="description"><?php esc_html_e( 'Traka se ne prikazuje u već instaliranoj aplikaciji ni na košarici i plaćanju. Na iPhoneu se prikazuje uputa Podijeli > Dodaj na početni zaslon.', 'plan-a-aplikacija' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Statistika', 'plan-a-aplikacija' ); ?></th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[stats]" value="1" <?php checked( $s['stats'] ); ?>> <?php esc_html_e( 'Anonimno brojanje instalacija i korištenja aplikacije', 'plan-a-aplikacija' ); ?></label>
							<p class="description"><?php esc_html_e( 'Bez kolačića, IP adresa i podataka o korisnicima; sprema se samo dnevni zbroj po platformi. Rezultati: kartica Statistika.', 'plan-a-aplikacija' ); ?></p>
						</td>
					</tr>
				</table>
				<p class="description"><?php esc_html_e( 'Adrese upišite kao putanju na ovoj stranici, npr. /izleti/.', 'plan-a-aplikacija' ); ?></p>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Kartica "Statistika" (samo administrator).
	 */
	private static function render_stats() {
		$days     = Plan_A_App_Stats::by_day( 30 );
		$all      = Plan_A_App_Stats::all_time();
		$labels   = array(
			'android' => 'Android',
			'ios'     => 'iPhone',
			'other'   => __( 'Ostalo', 'plan-a-aplikacija' ),
		);
		$first_all = array_fill_keys( array_keys( $labels ), 0 );
		foreach ( $all as $platform => $metrics ) {
			if ( isset( $first_all[ $platform ] ) ) {
				$first_all[ $platform ] = (int) ( $metrics['first'] ?? 0 );
			}
		}
		$installs_total = array_sum( $first_all );
		$day7           = Plan_A_App_Stats::sum( $days, 'day', 7 );
		$day30          = Plan_A_App_Stats::sum( $days, 'day', 30 );
		$open7          = Plan_A_App_Stats::sum( $days, 'open', 7 );
		$open30         = Plan_A_App_Stats::sum( $days, 'open', 30 );
		$first30        = Plan_A_App_Stats::sum( $days, 'first', 30 );
		$fmt            = static function ( $number, $decimals = 0 ) {
			return number_format_i18n( (float) $number, $decimals );
		};
		$card = static function ( $title, $value, $note ) {
			echo '<div style="flex:1 1 200px;background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:14px 16px;">'
				. '<div style="color:#50575e;font-size:13px;">' . esc_html( $title ) . '</div>'
				. '<div style="font-size:28px;font-weight:600;line-height:1.3;margin:4px 0;">' . esc_html( $value ) . '</div>'
				. '<div style="color:#646970;font-size:12px;">' . esc_html( $note ) . '</div></div>';
		};

		if ( ! Plan_A_App_Settings::get( 'stats' ) ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Brojanje je isključeno u postavkama, pa se novi podaci ne prikupljaju.', 'plan-a-aplikacija' ) . '</p></div>';
		}
		?>
		<p><?php esc_html_e( 'Brojanje počinje kad je ova verzija dodatka instalirana. Aplikacija javlja samo kad se otvori kao instalirana aplikacija (s početnog zaslona). Administratori se ne broje.', 'plan-a-aplikacija' ); ?></p>

		<div style="display:flex;flex-wrap:wrap;gap:12px;margin:16px 0;">
			<?php
			$card(
				__( 'Instalacije (ukupno)', 'plan-a-aplikacija' ),
				$fmt( $installs_total ),
				sprintf( 'Android %s · iPhone %s · %s %s', $fmt( $first_all['android'] ), $fmt( $first_all['ios'] ), $labels['other'], $fmt( $first_all['other'] ) )
			);
			$card(
				__( 'Nove instalacije, 30 dana', 'plan-a-aplikacija' ),
				$fmt( $first30['all'] ),
				sprintf( 'Android %s · iPhone %s', $fmt( $first30['android'] ), $fmt( $first30['ios'] ) )
			);
			$card(
				__( 'Aktivnih uređaja dnevno (prosjek 7 dana)', 'plan-a-aplikacija' ),
				$fmt( $day7['all'] / 7, 1 ),
				sprintf( __( 'prosjek 30 dana: %s', 'plan-a-aplikacija' ), $fmt( $day30['all'] / 30, 1 ) )
			);
			$card(
				__( 'Otvaranja aplikacije, 7 dana', 'plan-a-aplikacija' ),
				$fmt( $open7['all'] ),
				sprintf( __( '30 dana: %s', 'plan-a-aplikacija' ), $fmt( $open30['all'] ) )
			);
			$card(
				__( 'Otvaranja po aktivnom danu', 'plan-a-aplikacija' ),
				$day30['all'] ? $fmt( $open30['all'] / $day30['all'], 1 ) : '–',
				__( 'koliko puta uređaj otvori aplikaciju u danu kad je koristi (30 dana)', 'plan-a-aplikacija' )
			);
			$card(
				__( 'Aktivnih dana po instalaciji, 30 dana', 'plan-a-aplikacija' ),
				$installs_total ? $fmt( $day30['all'] / $installs_total, 1 ) : '–',
				__( 'koliko dana u zadnjih 30 se aplikacija prosječno koristila', 'plan-a-aplikacija' )
			);
			?>
		</div>

		<?php self::render_bookings( $all, $card, $fmt ); ?>

		<h2><?php esc_html_e( 'Zadnjih 30 dana', 'plan-a-aplikacija' ); ?></h2>
		<table class="widefat striped" style="max-width:900px;">
			<thead>
				<tr>
					<th rowspan="2"><?php esc_html_e( 'Datum', 'plan-a-aplikacija' ); ?></th>
					<?php foreach ( $labels as $label ) : ?>
						<th colspan="3" style="text-align:center;"><?php echo esc_html( $label ); ?></th>
					<?php endforeach; ?>
				</tr>
				<tr>
					<?php foreach ( $labels as $label ) : ?>
						<th><?php esc_html_e( 'Aktivni', 'plan-a-aplikacija' ); ?></th>
						<th><?php esc_html_e( 'Otvaranja', 'plan-a-aplikacija' ); ?></th>
						<th><?php esc_html_e( 'Nove', 'plan-a-aplikacija' ); ?></th>
					<?php endforeach; ?>
				</tr>
			</thead>
			<tbody>
				<?php
				$today = strtotime( current_time( 'Y-m-d' ) );
				for ( $i = 0; $i < 30; $i++ ) :
					$day  = gmdate( 'Y-m-d', $today - $i * DAY_IN_SECONDS );
					$data = $days[ $day ] ?? array();
					?>
					<tr>
						<td><?php echo esc_html( wp_date( 'j. n. Y.', strtotime( $day . ' 12:00:00' ) ) ); ?></td>
						<?php foreach ( array_keys( $labels ) as $platform ) : ?>
							<?php foreach ( array( 'day', 'open', 'first' ) as $metric ) : ?>
								<td><?php echo esc_html( $fmt( $data[ $platform ][ $metric ] ?? 0 ) ); ?></td>
							<?php endforeach; ?>
						<?php endforeach; ?>
					</tr>
				<?php endfor; ?>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Kako se broji', 'plan-a-aplikacija' ); ?></h2>
		<ul style="list-style:disc;padding-left:20px;max-width:900px;">
			<li><?php esc_html_e( 'Instalacija = prvo otvaranje aplikacije na uređaju. Ponovna instalacija na istom uređaju broji se ponovno. Brisanje aplikacije telefoni ne javljaju, pa ukupan broj instalacija nije broj aplikacija koje su danas na mobitelima.', 'plan-a-aplikacija' ); ?></li>
			<li><?php esc_html_e( 'Aktivni = broj uređaja koji su taj dan barem jednom otvorili aplikaciju. Ovo je najpouzdaniji pokazatelj stvarnog korištenja.', 'plan-a-aplikacija' ); ?></li>
			<li><?php esc_html_e( 'Otvaranja = koliko je puta aplikacija pokrenuta.', 'plan-a-aplikacija' ); ?></li>
			<li><?php esc_html_e( 'Rezervacija iz aplikacije = narudžba s izletom koju je kupac poslao klikom na konačni gumb za plaćanje dok je stranica bila otvorena kao instalirana aplikacija. „Plaćene / potvrđene” su narudžbe u statusu U obradi, Završeno ili Na čekanju. Izvor se vidi i na stranici same narudžbe.', 'plan-a-aplikacija' ); ?></li>
			<li><?php esc_html_e( 'Ne sprema se ništa po čemu bi se mogla prepoznati osoba ili uređaj: bez kolačića, IP adresa i identifikatora.', 'plan-a-aplikacija' ); ?></li>
		</ul>
		<?php
	}

	/**
	 * Rezervacije izleta iz aplikacije (narudžbe stvorene klikom na konačni gumb za plaćanje).
	 */
	private static function render_bookings( array $all, callable $card, callable $fmt ) {
		$summary = Plan_A_App_Orders::summary( 30 );
		$labels  = Plan_A_App_Orders::labels();
		$money   = static function ( $amount, $currency = '' ) {
			return function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( $amount, $currency ? array( 'currency' => $currency ) : array() ) ) : number_format_i18n( $amount, 2 );
		};
		$total_all_time = 0;
		foreach ( $all as $metrics ) {
			$total_all_time += (int) ( $metrics['booking'] ?? 0 );
		}
		?>
		<h2><?php esc_html_e( 'Rezervacije izleta iz aplikacije', 'plan-a-aplikacija' ); ?></h2>
		<?php if ( ! $summary['available'] ) : ?>
			<p><?php esc_html_e( 'WooCommerce nije aktivan.', 'plan-a-aplikacija' ); ?></p>
			<?php
			return;
		endif;
		?>
		<div style="display:flex;flex-wrap:wrap;gap:12px;margin:16px 0;">
			<?php
			$card(
				__( 'Poslane rezervacije, 30 dana', 'plan-a-aplikacija' ),
				$fmt( $summary['app_placed']['all'] ),
				sprintf( 'Android %s · iPhone %s · %s', $fmt( $summary['app_placed']['android'] ), $fmt( $summary['app_placed']['ios'] ), __( 'klik na konačni gumb za plaćanje', 'plan-a-aplikacija' ) )
			);
			$card(
				__( 'Plaćene / potvrđene, 30 dana', 'plan-a-aplikacija' ),
				$fmt( $summary['app_confirmed']['all'] ),
				sprintf( __( 'iznos: %s', 'plan-a-aplikacija' ), $money( $summary['app_revenue']['all'] ) )
			);
			$card(
				__( 'Udio aplikacije u rezervacijama izleta', 'plan-a-aplikacija' ),
				$summary['site_confirmed'] ? $fmt( 100 * $summary['app_confirmed']['all'] / $summary['site_confirmed'], 0 ) . ' %' : '–',
				sprintf( __( 'od %s plaćenih/potvrđenih rezervacija izleta na stranici u 30 dana', 'plan-a-aplikacija' ), $fmt( $summary['site_confirmed'] ) )
			);
			$card(
				__( 'Poslane rezervacije, ukupno', 'plan-a-aplikacija' ),
				$fmt( $total_all_time ),
				__( 'od instalacije ove verzije dodatka', 'plan-a-aplikacija' )
			);
			?>
		</div>
		<?php if ( $summary['recent'] ) : ?>
			<table class="widefat striped" style="max-width:900px;margin-bottom:24px;">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Narudžba', 'plan-a-aplikacija' ); ?></th>
						<th><?php esc_html_e( 'Datum', 'plan-a-aplikacija' ); ?></th>
						<th><?php esc_html_e( 'Platforma', 'plan-a-aplikacija' ); ?></th>
						<th><?php esc_html_e( 'Izlet', 'plan-a-aplikacija' ); ?></th>
						<th><?php esc_html_e( 'Status', 'plan-a-aplikacija' ); ?></th>
						<th><?php esc_html_e( 'Iznos', 'plan-a-aplikacija' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $summary['recent'] as $row ) : ?>
						<tr>
							<td><a href="<?php echo esc_url( $row['url'] ); ?>">#<?php echo esc_html( (string) $row['number'] ); ?></a></td>
							<td><?php echo esc_html( $row['date'] ? wp_date( 'j. n. Y. H:i', $row['date'] ) : '–' ); ?></td>
							<td><?php echo esc_html( $labels[ $row['source'] ] ?? $row['source'] ); ?></td>
							<td><?php echo esc_html( implode( ', ', $row['tours'] ) ); ?></td>
							<td><?php echo esc_html( $row['status'] ); ?></td>
							<td><?php echo esc_html( $money( $row['total'], $row['currency'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php else : ?>
			<p><?php esc_html_e( 'U zadnjih 30 dana još nema rezervacija izleta iz aplikacije.', 'plan-a-aplikacija' ); ?></p>
		<?php endif; ?>
		<?php
	}

	private static function status_notices( array $icons ) {
		$notices = array();
		if ( ! is_ssl() && 'localhost' !== wp_parse_url( home_url(), PHP_URL_HOST ) ) {
			$notices[] = array( 'error', __( 'Stranica ne koristi HTTPS. Service worker i instalacija rade samo preko HTTPS-a.', 'plan-a-aplikacija' ) );
		}
		if ( $icons['error'] ) {
			$notices[] = array( 'error', $icons['error'] );
		}
		if ( ! Plan_A_App_Settings::get( 'logo_id' ) ) {
			$notices[] = array( 'warning', get_site_icon_url( 512 ) ? __( 'Logotip nije odabran: koristi se ikona stranice (Izgled > Prilagodba > Identitet stranice). Za najbolji izgled odaberite logotip.', 'plan-a-aplikacija' ) : __( 'Odaberite logotip. Bez ikone aplikacija se ne može instalirati.', 'plan-a-aplikacija' ) );
		}
		foreach ( $notices as $notice ) {
			echo '<div class="notice notice-' . esc_attr( $notice[0] ) . ' inline"><p>' . esc_html( $notice[1] ) . '</p></div>';
		}
	}
}
