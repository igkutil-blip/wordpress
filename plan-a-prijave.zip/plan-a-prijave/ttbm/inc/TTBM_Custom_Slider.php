<?php
	/*
* @Author 		engr.sumonazma@gmail.com
* Copyright: 	mage-people.com
*/
	if (!defined('ABSPATH')) {
		die;
	} // Cannot access pages directly.
	//echo '<pre>';print_r();echo '</pre>';
	if (!class_exists('TTBM_Custom_Slider')) {
		class TTBM_Custom_Slider {
			public function __construct() {
				add_action('add_ttbm_custom_slider', array($this, 'super_slider'), 10, 2);
				add_action('add_ttbm_custom_slider_only', array($this, 'super_slider_only'));
				add_action('add_ttbm_custom_slider_icon_indicator', array($this, 'icon_indicator'));
				add_action('add_ttbm_featured_image_slider', array($this, 'featured_image_slider'), 10, 1);
			}
			public function super_slider($post_id = '', $meta_key = '') {
				$type = TTBM_Global_Function::get_slider_settings('slider_type', 'slider');
				$post_id = $post_id > 0 ? $post_id : get_the_id();
				$image_ids = $this->get_slider_ids($post_id, $meta_key);
				if (is_array($image_ids) && sizeof($image_ids) > 0) {
					if ($type == 'slider' && sizeof($image_ids) > 1) {
						$this->slider($post_id, $image_ids);
					} else {
						$this->post_thumbnail($image_ids[0]);
					}
				} else {
					$this->post_thumbnail();
				}
			}
			public function super_slider_only($image_ids) {
				if (is_array($image_ids) && sizeof($image_ids) > 0) {
					?>
                    <div class="superSlider placeholder_area">
						<?php $this->slider_all_item($image_ids); ?>
                    </div>
					<?php
				}
			}
			public function featured_image_slider($post_id = '') {
				$post_id = $post_id > 0 ? $post_id : get_the_id();
				$thumb_id = get_post_thumbnail_id($post_id);
				if (!$thumb_id) {
					return;
				}
				?>
				<div class="superSlider placeholder_area ttbm-featured-only">
					<?php $this->slider_all_item(array($thumb_id)); ?>
				</div>
				<?php
			}
			public function slider($post_id, $image_ids) {
				if (is_array($image_ids) && sizeof($image_ids) > 0) {
					$showcase_position = TTBM_Global_Function::get_slider_settings('showcase_position', 'right');
					$column_class = $showcase_position == 'top' || $showcase_position == 'bottom' ? 'area_column' : '';
					$slider_style = TTBM_Global_Function::get_slider_settings('slider_style', 'style_1');
					?>
                    <div class="superSlider placeholder_area fdColumn">
                        <input type="hidden" name="slider_height_type" value="<?php echo esc_attr(TTBM_Global_Function::get_slider_settings('slider_height', 'avg')); ?>"/>
                        <div class="dFlex ttbm_slider-wrapper <?php echo esc_attr($column_class); ?>">
							<?php
								if ($showcase_position == 'top' || $showcase_position == 'left') {
									$this->slider_showcase($image_ids);
								}
								$this->slider_all_item($image_ids);
								if ($showcase_position == 'bottom' || $showcase_position == 'right') {
									$this->slider_showcase($image_ids);
								}
								if ($slider_style == 'style_2') {
									?>
                                    <div class="abTopLeft">
                                        <button type="button" class="_dButton_bgWhite_textDefault" data-target-popup="superSlider" data-slide-index="1">
											<?php echo esc_html__('View All', 'tour-booking-manager') . ' ' . esc_html(sizeof($image_ids)) . ' ' . esc_html__('Images', 'tour-booking-manager'); ?>
                                        </button>
                                    </div>
									<?php
								}
							?>
                        </div>
						<?php
							$slider_indicator = TTBM_Global_Function::get_slider_settings('indicator_visible', 'on');
							$icon = TTBM_Global_Function::get_slider_settings('indicator_type', 'icon');
							if ($slider_indicator == 'on' && $icon == 'image') {
								$this->image_indicator($image_ids);
							}
						?>
						<?php $this->slider_popup($post_id, $image_ids); ?>
                    </div>
					<?php
				}
			}
			public function post_thumbnail($image_id = '') {
				$thumbnail = TTBM_Global_Function::get_image_url('', $image_id);
				if ($thumbnail && $image_id) {
					?>
                    <div class="superSlider placeholder_area">
						<?php $this->slider_all_item(array($image_id)); ?>
                    </div>
					<?php
				}
			}
			private static function render_bg_layer($image_url, $width = 0, $height = 0) {
				$image_url = esc_url($image_url);
				if (!$image_url) {
					return;
				}
				?>
				<div data-bg-image="<?php echo esc_attr($image_url); ?>"
					<?php if ($width) { ?>data-width="<?php echo esc_attr($width); ?>"<?php } ?>
					<?php if ($height) { ?>data-height="<?php echo esc_attr($height); ?>"<?php } ?>
					style="background-image:url('<?php echo esc_url($image_url); ?>');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;"></div>
				<?php
			}
			public function slider_all_item($image_ids, $popup_slider_icon = '') {
				if (is_array($image_ids) && sizeof($image_ids) > 0) {
					?>
                    <div class="sliderAllItem">
						<?php
							$count = 1;
							foreach ($image_ids as $id) {
								$image_url = TTBM_Global_Function::get_image_url('', $id, 'pap_hero'); // Plan A: 1800 px (za starije slike: izvornik)
								$image_url = $image_url ?: TTBM_PLUGIN_URL . '/assets/images/no_image.png';
								$metadata = wp_get_attachment_metadata($id);
								$width = 0;
								$height = 0;
								if (is_array($metadata)) {
									$width = isset($metadata['width']) ? absint($metadata['width']) : 0;
									$height = isset($metadata['height']) ? absint($metadata['height']) : 0;
								}
								?>
                                <div class="sliderItem" data-slide-index="<?php echo esc_html($count); ?>" data-target-popup="superSlider" data-placeholder>
									<?php self::render_bg_layer($image_url, $width, $height); ?>
                                </div>
								<?php
								$count++;
							}
						?>
						<?php
							$icon = TTBM_Global_Function::get_slider_settings('indicator_type', 'icon');
							if (($icon == 'icon' || $popup_slider_icon == 'on') && sizeof($image_ids) > 1) {
								$this->icon_indicator($popup_slider_icon);
							}
						?>
						<?php do_action( 'ttbm_slider_all_item_overlay' ); ?>
                    </div>
					<?php
				}
			}
			public function slider_showcase($image_ids) {
				$showcase = TTBM_Global_Function::get_slider_settings('showcase_visible', 'on');
				if ($showcase == 'on' && is_array($image_ids) && sizeof($image_ids) > 0) {
					$showcase_position = TTBM_Global_Function::get_slider_settings('showcase_position', 'right');
					$slider_style = TTBM_Global_Function::get_slider_settings('slider_style', 'style_1');
					?>
                    <div class="sliderShowcase <?php echo esc_attr($showcase_position . ' ' . $slider_style); ?>">
						<?php
							if ($slider_style == 'style_1') {
								$this->slider_showcase_style_1($image_ids);
							} else {
								$this->slider_showcase_style_2($image_ids);
							}
						?>
                    </div>
					<?php
				}
			}
			public function slider_showcase_style_1($image_ids) {
				$count = 1;
				foreach ($image_ids as $id) {
					$image_url = TTBM_Global_Function::get_image_url('', $id);
					if ($count < 4) {
						?>
                        <div class="sliderShowcaseItem" data-slide-target="<?php echo esc_html($count); ?>" data-placeholder>
							<?php self::render_bg_layer($image_url); ?>
                        </div>
						<?php
					}
					if ($count == 4) {
						?>
                        <div class="sliderShowcaseItem" data-target-popup="superSlider" data-placeholder>
							<?php self::render_bg_layer($image_url); ?>
                            <div class="sliderMoreItem">
                                <span class="fas fa-plus"></span>
								<?php echo esc_html(sizeof($image_ids) - 4); ?>
                                <span class="far fa-image"></span>
                            </div>
                        </div>
						<?php
					}
					$count++;
				}
			}
			public function slider_showcase_style_2($image_ids) {
				$count = 1;
				foreach ($image_ids as $id) {
					$image_url = TTBM_Global_Function::get_image_url('', $id);
					if ($count > 1 && $count < 5) {
						?>
                        <div class="sliderShowcaseItem" data-target-popup="superSlider" data-slide-index="<?php echo esc_html($count); ?>" data-placeholder>
							<?php self::render_bg_layer($image_url); ?>
                        </div>
						<?php
					}
					$count++;
				}
			}
			public function image_indicator($image_ids) {
				if (is_array($image_ids) && sizeof($image_ids) > 0) {
					?>
                    <div class="slideIndicator">
						<?php
							$count = 1;
							foreach ($image_ids as $id) {
								$image_url = TTBM_Global_Function::get_image_url('', $id, array(150, 100));
								?>
                                <div class="slideIndicatorItem" data-slide-target="<?php echo esc_html($count); ?>">
									<?php self::render_bg_layer($image_url); ?>
                                </div>
								<?php
								$count++;
							}
						?>
                    </div>
					<?php
				}
			}
			public function icon_indicator($popup_slider_icon = '') {
				$slider_indicator = TTBM_Global_Function::get_slider_settings('indicator_visible', 'on');
				if ($slider_indicator == 'on' || $popup_slider_icon == 'on') {
					?>
                    <div class="iconIndicator prevItem">
                        <span class="fas fa-chevron-circle-left"></span>
                    </div>
                    <div class="iconIndicator nextItem">
                        <span class="fas fa-chevron-circle-right"></span>
                    </div>
					<?php
				}
			}
			public function slider_popup($post_id, $image_ids) {
				if (is_array($image_ids) && sizeof($image_ids) > 0) {
					$popup_icon_indicator = TTBM_Global_Function::get_slider_settings('popup_icon_indicator', 'on');
					?>
                    <div class="sliderPopup" data-popup="superSlider">
                        <div class="superSlider">
                            <div class="popupHeader">
                                <h2><?php echo esc_html(get_the_title($post_id)); ?></h2>
                                <span class="fas fa-times popupClose"></span>
                            </div>
                            <div class="popupBody">
								<?php $this->slider_all_item($image_ids, $popup_icon_indicator); ?>
                            </div>
                            <div class="popupFooter">
								<?php
									$indicator = TTBM_Global_Function::get_slider_settings('popup_image_indicator', 'on');
									if ($indicator == 'on') {
										$this->image_indicator($image_ids);
									}
								?>
                            </div>
                        </div>
                    </div>
					<?php
				}
			}
			//==============//
			public function get_slider_ids($post_id, $key) {
				$thumb_id = get_post_thumbnail_id($post_id);
				$image_ids = TTBM_Global_Function::get_post_info($post_id, $key, array());
				if ($thumb_id) {
					array_unshift($image_ids, $thumb_id);
				}
				return array_unique($image_ids);
			}
		}
		new TTBM_Custom_Slider();
	}
