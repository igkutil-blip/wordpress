<?php
	if ( ! defined( 'ABSPATH' ) ) {
		die;
	}
	$ttbm_post_id = $ttbm_post_id ?? get_the_id();
	$start_place = TTBM_Global_Function::get_post_info($ttbm_post_id, 'ttbm_travel_start_place');
	$tour_type = TTBM_Function::get_tour_type( $ttbm_post_id );
	$count = $count ?? 0;
	if ( $start_place && $tour_type == 'general' && TTBM_Global_Function::get_post_info( $ttbm_post_id, 'ttbm_display_start_location', 'on' ) != 'off' ) {
?>
	
<div class="item_icon<?php echo esc_attr( TTBM_Function::hero_stat_item_class() ); ?>" title="<?php esc_html_e( 'Start Location', 'tour-booking-manager' ); ?>">
	<i class="mi mi-marker"></i>
	<span><?php echo esc_html( $start_place ); ?></span>
</div>

<?php
// FIXED: Removed indentation before PHP tags to prevent whitespace output - 2025-01-21 by Shahnur Alam
$count ++;
}
	?>