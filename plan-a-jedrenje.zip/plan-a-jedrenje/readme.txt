=== Plan A jedrenje ===
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Rezervacija tjednog jedrenja za ekipu (subota–subota) u terminu koji kupac bira.

== Kako radi ==

1. Shortcode [plan-a-jedrenje] prikazuje rezervacijski blok: brod, polazak, ekipa, cijena
   "od … za cijeli brod", uključeno (kvačice) i nije uključeno, kalendar tjedana, sažetak
   odabranog tjedna, obrazac za zahtjev i gumb "Predloži ekipi".
2. Kalendar: samo tjedni sezone (ova i sljedeća godina), bez prošlih. Slobodno (plavi obrub),
   Na upitu (narančasto, još se može poslati zahtjev), Zauzeto (sivo, ne može se odabrati).
   Mobitel: jedan mjesec, gumbi za prethodni i sljedeći, kartice u dva stupca. Računalo: tri mjeseca.
3. Cijena je uvijek za cijeli brod: ručna cijena tjedna > cijena razdoblja (subota ukrcaja) >
   osnovna cijena. Uz cijenu se može prikazati precrtana redovna cijena. Ispod cijene:
   "Za X osoba to je Y € po osobi".
4. Zahtjev (bez plaćanja): tjedan postaje "Na upitu", kupac dobiva e-mail "Zahtjev je zaprimljen",
   administrator e-mail s poveznicom.
5. Administracija → Jedrenje → Zahtjevi → "Brod je slobodan, pošalji uplatnicu": izrađuje se
   WooCommerce narudžba (virman, "Na čekanju") na iznos akontacije (30 %), pa kupac dobiva
   e-mail s uplatnicom i 2D kodom (dodatak Hub3) i rokom uplate (5 dana). Ako je do ukrcaja
   manje od 30 dana, traži se cijeli iznos. "Odbij" šalje kupcu poruku.
6. Rezervacije → "Uplata akontacije je stigla" (ili narudžba u WooCommerceu prebačena u
   "U obradi"): tjedan postaje zauzet, kupac dobiva potvrdu s rokom za ostatak.
7. "Pošalji uplatnicu za ostatak" izrađuje drugu narudžbu na ostatak; "Uplata ostatka je stigla"
   zatvara rezervaciju ("Sve plaćeno").
8. Poklon bon: e-mail s uplatnicom ima poveznicu "Plati preko košarice". Uplata je tada u
   košarici (Plan A košarica), kupac upiše kod s bona u polje za kod i plati preko naplate;
   narudžba administratora za taj dio se sama otkazuje.
9. Podsjetnik administratoru jednom dnevno: akontacija nije uplaćena u roku (tjedan se NE
   oslobađa sam – "Otkaži rezervaciju i oslobodi tjedan"), rok za ostatak za 7 dana, ostatak kasni.

Zaštita: cijena, broj osoba, ruta i stanje tjedna provjeravaju se na poslužitelju; tjedan se
zaključava pri promjeni stanja; za tjedan s poslanom uplatnicom ne može se poslati druga; nonce,
prava pristupa (manage_woocommerce), ograničenje zahtjeva po IP adresi, skriveno polje protiv botova.

== Predmemorija (SpeedyCache) ==

Stanja tjedana i nonce uvijek se dohvaćaju svježe preko /wp-admin/admin-ajax.php, pa blok radi
i na stranici iz predmemorije. Ipak izuzmi:
* stranicu s rezervacijom, npr. /jedrenje/
* adrese s parametrom paj_plati (poveznica za plaćanje preko košarice)
* /wp-admin/admin-ajax.php (obično nikad nije u predmemoriji)
Košarica, naplata i "Moj račun" već moraju biti izuzeti zbog WooCommercea.

== Promjene ==

= 1.0.0 =
* Prva inačica.
